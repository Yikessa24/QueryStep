import torch
from torch import nn
from torch.nn.init import xavier_uniform_
from torch.nn.init import constant_
import math
import torch.nn.functional as F
from enum import IntEnum
import numpy as np
from torch.nn.parameter import Parameter
from einops import rearrange, repeat
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class Dim(IntEnum):
    batch = 0
    seq = 1
    feature = 2

class EpiKT(nn.Module):
    def __init__(self, n_question, n_pid, d_model, n_blocks, dropout, d_ff=256, num_buckets=32, max_distance=100, init_c=0.1, init_L=200, bar_d=128,
            kq_same=1, final_fc_dim=512, num_attn_heads=8, separate_qa=False, l2=1e-5, emb_type="qid", emb_path="", pretrain_dim=768,
            n_scales=2, epikt_ablation="full"):
        super().__init__()
        self.model_name = "epikt"
        self.n_question = n_question
        self.dropout = dropout
        self.kq_same = kq_same
        self.n_pid = n_pid
        self.l2 = l2
        self.model_type = self.model_name
        self.separate_qa = separate_qa
        self.emb_type = emb_type
        self.epikt_ablation = epikt_ablation
        valid_epikt_ablations = {
            "full",
            "w/o Multi-scale Episodes",
            "w/o Level-aware Expansion",
            "w/o Complementary Head",
            "w/o Dynamic Gate",
            "w/o Branch-specific Predictors",
        }
        if epikt_ablation not in valid_epikt_ablations:
            raise ValueError(f"unsupported epikt_ablation: {epikt_ablation}")
        if epikt_ablation == "w/o Multi-scale Episodes":
            n_scales = 1
        self.n_scales = n_scales
        embed_l = d_model

        # EpiKT paper: Interaction Encoder.
        if self.n_pid > 0:
            self.difficult_param = nn.Embedding(self.n_pid+1, 1)
            self.q_embed_diff = nn.Embedding(self.n_question+1, embed_l)
            self.qa_embed_diff = nn.Embedding(2 * self.n_question + 1, embed_l)
        
        if emb_type.startswith("qid"):
            self.q_embed = nn.Embedding(self.n_question, embed_l)
            if self.separate_qa: 
                self.qa_embed = nn.Embedding(2*self.n_question+1, embed_l)
            else:
                self.qa_embed = nn.Embedding(2, embed_l)

        self.model = Architecture(
            n_question=n_question, n_blocks=n_blocks, n_heads=num_attn_heads, dropout=dropout,
            d_model=d_model, d_feature=d_model // num_attn_heads, d_ff=d_ff, kq_same=self.kq_same,
            model_type=self.model_type, emb_type=self.emb_type,
            num_buckets=num_buckets, max_distance=max_distance,
            init_c=init_c, init_L=init_L, bar_d=bar_d,
            n_scales=n_scales, epikt_ablation=epikt_ablation)

        if epikt_ablation == "w/o Complementary Head":
            self.out = nn.Sequential(
                nn.Linear(d_model + embed_l, final_fc_dim), nn.ReLU(), nn.Dropout(self.dropout),
                nn.Linear(final_fc_dim, 256), nn.ReLU(), nn.Dropout(self.dropout),
                nn.Linear(256, 1)
            )
        else:
            self.out = MultiBranchComplementaryPredictionHead(
                input_dim=d_model + embed_l,
                hidden_dim=final_fc_dim,
                dropout=self.dropout,
                n_branches=n_scales,
                epikt_ablation=epikt_ablation,
            )
        self.reset()

    def reset(self):
        for p in self.parameters():
            if p.dim() > 0 and p.size(0) == self.n_pid+1 and self.n_pid > 0:
                torch.nn.init.constant_(p, 0.)

    def base_emb(self, q_data, target):
        q_embed_data = self.q_embed(q_data)
        if self.separate_qa:
            qa_data = q_data + self.n_question * target
            qa_embed_data = self.qa_embed(qa_data)
        else:
            qa_embed_data = self.qa_embed(target) + q_embed_data
        return q_embed_data, qa_embed_data

    def forward(self, q_data, target, pid_data=None, qtest=False):
        emb_type = self.emb_type
        if emb_type.startswith("qid"):
            q_embed_data, qa_embed_data = self.base_emb(q_data, target)

        pid_embed_data = None
        if self.n_pid > 0:
            q_embed_diff_data = self.q_embed_diff(q_data)
            pid_embed_data = self.difficult_param(pid_data)
            q_embed_data = q_embed_data + pid_embed_data * q_embed_diff_data

            qa_embed_diff_data = self.qa_embed_diff(target)
            if self.separate_qa:
                qa_embed_data = qa_embed_data + pid_embed_data * qa_embed_diff_data
            else:
                qa_embed_data = qa_embed_data + pid_embed_data * (qa_embed_diff_data + q_embed_diff_data)
            c_reg_loss = (pid_embed_data ** 2.).sum() * self.l2
        else:
            c_reg_loss = 0.

        d_output = self.model(q_embed_data, qa_embed_data, pid_embed_data)

        if self.epikt_ablation == "w/o Complementary Head":
            d_output = d_output.mean(dim=2)
            concat_q = torch.cat([d_output, q_embed_data], dim=-1)
        else:
            expanded_q = q_embed_data.unsqueeze(2).expand(-1, -1, d_output.size(2), -1)
            concat_q = torch.cat([d_output, expanded_q], dim=-1)
        output = self.out(concat_q).squeeze(-1)
        m = nn.Sigmoid()
        preds = m(output)

        if (not self.training) and (not hasattr(self, "_printed_branch_gates")):
            if hasattr(self.out, "last_branch_gates"):
                gate_mean = self.out.last_branch_gates.mean(dim=(0, 1)).detach().cpu()
                print("mean branch gates:", gate_mean)
            self._printed_branch_gates = True

        if not qtest:
            return preds, c_reg_loss
        else:
            return preds, c_reg_loss, concat_q


class MultiBranchComplementaryPredictionHead(nn.Module):
    """EpiKT paper: Episode-aware Complementary Prediction."""

    def __init__(self, input_dim, hidden_dim, dropout, n_branches, epikt_ablation="full"):
        super().__init__()
        self.n_branches = n_branches
        self.epikt_ablation = epikt_ablation

        def make_branch_predictor():
            return nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, 256),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(256, 1)
            )

        if epikt_ablation == "w/o Branch-specific Predictors":
            self.shared_predictor = make_branch_predictor()
        else:
            self.predictors = nn.ModuleList([
                make_branch_predictor() for _ in range(n_branches)
            ])

        if epikt_ablation != "w/o Dynamic Gate":
            gate_hidden_dim = max(32, hidden_dim // 4)
            self.gate_scorer = nn.Sequential(
                nn.Linear(input_dim, gate_hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(gate_hidden_dim, 1)
            )
            self.branch_bias = nn.Parameter(torch.zeros(n_branches))
            self.log_temperature = nn.Parameter(torch.zeros(1))

    def forward(self, branch_features):
        squeeze_seq_dim = False
        if branch_features.dim() == 3:
            branch_features = branch_features.unsqueeze(1)
            squeeze_seq_dim = True
        elif branch_features.dim() != 4:
            raise ValueError(
                "branch_features must have shape [B, T, K, D] or [B, K, D], "
                f"got {tuple(branch_features.shape)}"
            )

        if branch_features.size(2) != self.n_branches:
            raise ValueError(
                f"expected {self.n_branches} branches, got {branch_features.size(2)}"
            )

        branch_logits = []

        for k in range(self.n_branches):
            branch_features_at_level = branch_features[:, :, k, :]
            if self.epikt_ablation == "w/o Branch-specific Predictors":
                branch_logit = self.shared_predictor(branch_features_at_level)
            else:
                branch_logit = self.predictors[k](branch_features_at_level)
            branch_logits.append(branch_logit)

        branch_logits = torch.cat(branch_logits, dim=-1)

        if self.epikt_ablation == "w/o Dynamic Gate":
            branch_gates = torch.ones_like(branch_logits) / self.n_branches
        else:
            gate_scores = self.gate_scorer(branch_features).squeeze(-1)
            gate_scores = gate_scores + self.branch_bias.view(1, 1, self.n_branches)
            temperature = torch.exp(self.log_temperature).clamp(min=0.5, max=5.0)
            branch_gates = F.softmax(gate_scores / temperature, dim=-1)

        fused_logit = (branch_logits * branch_gates).sum(dim=-1, keepdim=True)

        if squeeze_seq_dim:
            fused_logit = fused_logit.squeeze(1)
            branch_gates = branch_gates.squeeze(1)

        self.last_branch_gates = branch_gates.detach()

        return fused_logit


class Architecture(nn.Module):
    """EpiKT episode construction and contextualization architecture."""

    def __init__(self, n_question, n_blocks, d_model, d_feature,
                 d_ff, n_heads, dropout, kq_same, model_type, emb_type, num_buckets, max_distance, init_c, init_L, bar_d,
                 n_scales=2, epikt_ablation="full"):
        super().__init__()
        self.d_model = d_model
        self.model_type = model_type
        self.n_scales = n_scales
        self.epikt_ablation = epikt_ablation
        self.use_level_aware_expansion = epikt_ablation != "w/o Level-aware Expansion"

        def episode_level_dim(level):
            return d_model * (2 ** level) if self.use_level_aware_expansion else d_model

        # EpiKT paper: Hierarchical Episode Construction and Encoding.
        self.branch_encoders = nn.ModuleList()
        for level in range(n_scales):
            level_dim = episode_level_dim(level)
            level_head_dim = level_dim // n_heads
            level_ff_dim = d_ff * (2 ** level) if self.use_level_aware_expansion else d_ff
            level_encoder = nn.ModuleList([
                TransformerLayer(
                    d_model=level_dim, d_feature=level_head_dim,
                    d_ff=level_ff_dim, dropout=dropout, n_heads=n_heads, kq_same=kq_same,
                    emb_type=emb_type, num_buckets=num_buckets, max_distance=max_distance,
                    init_c=init_c, init_L=init_L, bar_d=bar_d)
                for _ in range(n_blocks)
            ])
            self.branch_encoders.append(level_encoder)

        self.cross_scale_convs = nn.ModuleList()
        for level in range(n_scales - 1):
            level_dim = episode_level_dim(level)
            next_level_dim = episode_level_dim(level + 1)
            self.cross_scale_convs.append(
                nn.Conv1d(in_channels=level_dim, out_channels=next_level_dim, kernel_size=2, stride=2)
            )

        self.upsample_projs = nn.ModuleList()
        for level in range(1, n_scales):
            level_dim = episode_level_dim(level)
            self.upsample_projs.append(nn.Linear(level_dim, d_model) if level_dim != d_model else nn.Identity())

        # EpiKT paper: Causal Episode Contextualization.
        self.blocks_2 = nn.ModuleList([
            TransformerLayer(
                d_model=d_model, d_feature=d_model // n_heads,
                d_ff=d_ff, dropout=dropout, n_heads=n_heads, kq_same=kq_same,
                emb_type=emb_type, num_buckets=num_buckets, max_distance=max_distance,
                init_c=init_c, init_L=init_L, bar_d=bar_d)
            for _ in range(n_blocks * 2)
        ])

    @property
    def shared_causal_retriever(self):
        """Shared causal knowledge retriever for all episode levels."""
        return self.blocks_2

    @staticmethod
    def _downsample_episode_difficulty(difficulty_states):
        """Aggregate question difficulty for the next episode level."""
        if difficulty_states.size(1) % 2 == 0:
            difficulty_states = F.pad(difficulty_states, (0, 0, 0, 1), mode='replicate')

        first_difficulty = difficulty_states[:, :1, :]
        remaining_difficulty = difficulty_states[:, 1:, :]
        if remaining_difficulty.size(1) == 0:
            return first_difficulty

        batch_size, _, feature_dim = remaining_difficulty.size()
        remaining_difficulty = remaining_difficulty.reshape(batch_size, -1, 2, feature_dim).mean(dim=2)
        return torch.cat([first_difficulty, remaining_difficulty], dim=1)

    @staticmethod
    def _downsample_episode_states(episode_states, downsampler):
        """Causally construct the next level of episode states."""
        if episode_states.size(1) % 2 == 0:
            episode_states = F.pad(episode_states, (0, 0, 0, 1), mode='replicate')
        episode_states = episode_states.permute(0, 2, 1)
        episode_states = F.pad(episode_states, (1, 0))
        return downsampler(episode_states).permute(0, 2, 1)

    @staticmethod
    def _downsample_episode_endpoints(episode_endpoints):
        """Propagate causal episode endpoints to the next level."""
        if episode_endpoints.size(0) % 2 == 0:
            episode_endpoints = torch.cat([episode_endpoints, episode_endpoints[-1:].clone()], dim=0)

        left_endpoint_pad = torch.full(
            (1,),
            -1,
            dtype=episode_endpoints.dtype,
            device=episode_endpoints.device
        )

        extended_endpoints = torch.cat([left_endpoint_pad, episode_endpoints], dim=0)
        endpoint_pairs = extended_endpoints.view(-1, 2)
        return endpoint_pairs.max(dim=1).values

    @staticmethod
    def _align_episode_states_by_endpoint(episode_states, episode_endpoints, item_sequence_length):
        """Align episode states to the item timeline by causal endpoint."""
        if episode_states.size(1) != episode_endpoints.size(0):
            raise ValueError(
                f"episode_states length {episode_states.size(1)} does not match "
                f"episode_endpoints length {episode_endpoints.size(0)}"
            )

        device = episode_states.device
        item_positions = torch.arange(item_sequence_length, device=device, dtype=episode_endpoints.dtype)
        aligned_episode_indices = torch.searchsorted(episode_endpoints, item_positions, right=True) - 1

        has_visible_episode = aligned_episode_indices >= 0
        aligned_episode_indices = aligned_episode_indices.clamp(min=0, max=episode_states.size(1) - 1)
        aligned_states = episode_states.index_select(dim=1, index=aligned_episode_indices)
        aligned_states = aligned_states * has_visible_episode.view(1, item_sequence_length, 1).to(aligned_states.dtype)
        return aligned_states

    def _run_shared_causal_retriever(self, q_embed_data, aligned_episode_history, pid_embed_data):
        """Retrieve one level-specific knowledge-state sequence."""
        x = q_embed_data
        flag_first = True
        for block in self.shared_causal_retriever:
            if flag_first:
                x = block(mask=1, query=x, key=x, values=x, apply_pos=False, pdiff=pid_embed_data)
                flag_first = False
            else:
                x = block(mask=0, query=x, key=x, values=aligned_episode_history, apply_pos=True, pdiff=pid_embed_data)
                flag_first = True
        return x

    def forward(self, q_embed_data, qa_embed_data, pid_embed_data):
        item_sequence_length = q_embed_data.size(1)

        episode_states = qa_embed_data
        encoded_levels = []
        level_endpoints = []

        episode_endpoints = torch.arange(
            item_sequence_length,
            device=q_embed_data.device,
            dtype=torch.long
        )

        difficulty_by_level = [pid_embed_data]
        if pid_embed_data is not None:
            current_level_difficulty = pid_embed_data
            for _ in range(self.n_scales - 1):
                current_level_difficulty = self._downsample_episode_difficulty(current_level_difficulty)
                difficulty_by_level.append(current_level_difficulty)

        for level in range(self.n_scales):
            level_difficulty = difficulty_by_level[level] if pid_embed_data is not None else None

            for block in self.branch_encoders[level]:
                episode_states = block(
                    mask=1,
                    query=episode_states,
                    key=episode_states,
                    values=episode_states,
                    pdiff=level_difficulty
                )

            encoded_levels.append(episode_states)
            level_endpoints.append(episode_endpoints)

            if level < self.n_scales - 1:
                episode_states = self._downsample_episode_states(
                    episode_states,
                    self.cross_scale_convs[level]
                )
                episode_endpoints = self._downsample_episode_endpoints(episode_endpoints)

        aligned_episode_histories = [encoded_levels[0]]

        # Project and endpoint-align each episode level.
        for level in range(1, self.n_scales):
            aligned_level_states = self.upsample_projs[level - 1](encoded_levels[level])
            aligned_level_states = self._align_episode_states_by_endpoint(
                episode_states=aligned_level_states,
                episode_endpoints=level_endpoints[level],
                item_sequence_length=item_sequence_length
            )
            aligned_episode_histories.append(aligned_level_states)

        # Apply the shared causal retriever to each aligned level.
        level_knowledge_states = []
        for aligned_episode_history in aligned_episode_histories:
            level_knowledge_states.append(
                self._run_shared_causal_retriever(
                    q_embed_data,
                    aligned_episode_history,
                    pid_embed_data
                )
            )

        return torch.stack(level_knowledge_states, dim=2)


class TransformerLayer(nn.Module):
    def __init__(self, d_model, d_feature,
                 d_ff, n_heads, dropout, kq_same, emb_type, num_buckets, max_distance, init_c, init_L, bar_d):
        super().__init__()
        kq_same = kq_same == 1
        self.masked_attn_head = MultiHeadAttention(
            d_model, d_feature, n_heads, dropout, kq_same=kq_same, emb_type=emb_type,
            num_buckets=num_buckets, max_distance=max_distance, init_c=init_c, init_L=init_L, bar_d=bar_d)

        self.layer_norm1 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)

        self.linear1 = nn.Linear(d_model, d_ff)
        self.activation = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(d_ff, d_model)

        self.layer_norm2 = nn.LayerNorm(d_model)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, mask, query, key, values, apply_pos=True, pdiff=None):
        seqlen, batch_size = query.size(1), query.size(0)
        nopeek_mask = np.triu(
            np.ones((1, 1, seqlen, seqlen)), k=mask).astype('uint8')
        src_mask = (torch.from_numpy(nopeek_mask) == 0).to(device)
        if mask == 0:
            query2 = self.masked_attn_head(
                query, key, values, mask=src_mask, zero_pad=True, pdiff=pdiff)
        else:
            query2 = self.masked_attn_head(
                query, key, values, mask=src_mask, zero_pad=False, pdiff=pdiff)

        query = query + self.dropout1((query2))
        query = self.layer_norm1(query)
        if apply_pos:
            query2 = self.linear2(self.dropout(
                self.activation(self.linear1(query))))
            query = query + self.dropout2((query2))
            query = self.layer_norm2(query)
        return query


class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, d_feature, n_heads, dropout, kq_same, num_buckets, max_distance, init_c, init_L, bar_d, bias=True, emb_type="qid"):
        super().__init__()
        self.d_model = d_model
        self.emb_type = emb_type
        self.bar_d = bar_d
        if emb_type.endswith("avgpool"):
            pool_size = 3
            self.pooling = nn.AvgPool1d(pool_size, stride=1, padding=pool_size//2, count_include_pad=False)
            self.out_proj = nn.Linear(d_model, d_model, bias=bias)
        elif emb_type.endswith("linear"):
            self.linear = nn.Linear(d_model, d_model, bias=bias)
            self.out_proj = nn.Linear(d_model, d_model, bias=bias)
        elif emb_type.startswith("qid"):
            self.d_k = d_feature
            self.h = n_heads
            self.kq_same = kq_same

            self.v_linear = nn.Linear(d_model, d_model, bias=bias)
            self.k_linear = nn.Linear(d_model, d_model, bias=bias)
            if kq_same is False:
                self.q_linear = nn.Linear(d_model, d_model, bias=bias)
            self.dropout = nn.Dropout(dropout)
            self.proj_bias = bias
            self.out_proj = nn.Linear(d_model, d_model, bias=bias)
            self.gammas = nn.Parameter(torch.zeros(n_heads, 1, 1))
            torch.nn.init.xavier_uniform_(self.gammas)

        if emb_type.find("alibi") != -1:
            def get_slopes(n):
                def get_slopes_power_of_2(n):
                    start = (2**(-2**-(math.log2(n)-3)))
                    ratio = start
                    return [start*ratio**i for i in range(n)]
                if math.log2(n).is_integer():
                    return get_slopes_power_of_2(n)
                else:
                    closest_power_of_2 = 2**math.floor(math.log2(n))
                    return get_slopes_power_of_2(closest_power_of_2) + get_slopes(2*closest_power_of_2)[0::2][:n-closest_power_of_2]
            maxpos = 1000
            attn_heads = n_heads
            context_position = torch.arange(maxpos)[:, None].cuda()
            memory_position = torch.arange(maxpos)[None, :].cuda()
            relative_position = memory_position - context_position
            relative_position = torch.abs(relative_position).unsqueeze(0).expand(attn_heads, -1, -1)
            self.slopes = torch.Tensor(get_slopes(attn_heads)).cuda()*-1
            self.bias = self.slopes.unsqueeze(1).unsqueeze(1) * relative_position
            self.bias = self.bias.view(1, attn_heads, maxpos, maxpos)
        elif emb_type.find("log") != -1:
            self.bias = ParallelKerpleLog(n_heads)
        elif emb_type.find("power") != -1:
            self.bias = ParallelKerplePower(n_heads)
        elif emb_type.find("t5") != -1:
            self.bias = T5RelativePositionBias(scale=d_model ** 0.5, causal=True, num_buckets=num_buckets, max_distance=max_distance)
        elif emb_type.find("fire") != -1:
            self.bias = FIRE(n_heads, d_feature, init_c, init_L)
        elif emb_type.find("sandwich") != -1:
            self.bias = None
        else:
            self.bias = None

        self._reset_parameters()

    def _reset_parameters(self):
        xavier_uniform_(self.k_linear.weight)
        xavier_uniform_(self.v_linear.weight)
        if self.kq_same is False:
            xavier_uniform_(self.q_linear.weight)
        if self.proj_bias:
            constant_(self.k_linear.bias, 0.)
            constant_(self.v_linear.bias, 0.)
            if self.kq_same is False:
                constant_(self.q_linear.bias, 0.)
            constant_(self.out_proj.bias, 0.)

    def forward(self, q, k, v, mask, zero_pad, pdiff=None):
        bs = q.size(0)

        if self.emb_type.endswith("avgpool"):
            scores = self.pooling(v)
            concat = self.pad_zero(scores, bs, scores.shape[2], zero_pad)
        elif self.emb_type.endswith("linear"):
            scores = self.linear(v)
            concat = self.pad_zero(scores, bs, scores.shape[2], zero_pad)
        elif self.emb_type.startswith("qid"):
            k = self.k_linear(k).view(bs, -1, self.h, self.d_k)
            if self.kq_same is False:
                q = self.q_linear(q).view(bs, -1, self.h, self.d_k)
            else:
                q = self.k_linear(q).view(bs, -1, self.h, self.d_k)
            v = self.v_linear(v).view(bs, -1, self.h, self.d_k)

            k = k.transpose(1, 2)
            q = q.transpose(1, 2)
            v = v.transpose(1, 2)
            gammas = self.gammas
            if self.emb_type.find("pdiff") == -1:
                pdiff = None
            scores = attention(q, k, v, self.d_k,
                            mask, self.dropout, zero_pad, gammas, pdiff, self.emb_type, self.bias, self.bar_d)
            concat = scores.transpose(1, 2).contiguous()\
                .view(bs, -1, self.d_model)

        output = self.out_proj(concat)
        return output

    def pad_zero(self, scores, bs, dim, zero_pad):
        if zero_pad:
            pad_zero = torch.zeros(bs, 1, dim).to(device)
            scores = torch.cat([pad_zero, scores[:, 0:-1, :]], dim=1)
        return scores


def attention(q, k, v, d_k, mask, dropout, zero_pad, gamma=None, pdiff=None, emb_type="qid", bias=None, bar_d=32):
    scores = torch.matmul(q, k.transpose(-2, -1)) / \
        math.sqrt(d_k)
    bs, head, seqlen = scores.size(0), scores.size(1), scores.size(2)

    if emb_type.find("alibi") != -1:
        scores = scores + bias[:, :, :seqlen, :seqlen]
    elif emb_type.find("log") != -1:
        scores = bias(scores)
    elif emb_type.find("power") != -1:
        scores = bias(scores)
    elif emb_type.find("t5") != -1:
        scores = scores + bias(scores)
    elif emb_type.find("fire") != -1:
        scores = scores + bias(q)
    elif emb_type.find("sandwich") != -1:
        multi_head_sandwich = compute_sandwich_transform(head, seqlen, bar_d, device=q.device)
        bias = multi_head_sandwich[None, ...]
        scores = scores + bias
    elif emb_type.find("noforgetting") != -1:
        scores = scores
    else:
        x1 = torch.arange(seqlen).expand(seqlen, -1).to(device)
        x2 = x1.transpose(0, 1).contiguous()

        with torch.no_grad():
            scores_ = scores.masked_fill(mask == 0, -1e32)
            scores_ = F.softmax(scores_, dim=-1)
            scores_ = scores_ * mask.float().to(device)
            distcum_scores = torch.cumsum(scores_, dim=-1)
            disttotal_scores = torch.sum(scores_, dim=-1, keepdim=True)
            position_effect = torch.abs(
                x1-x2)[None, None, :, :].type(torch.FloatTensor).to(device)
            dist_scores = torch.clamp(
                (disttotal_scores-distcum_scores)*position_effect, min=0.)
            dist_scores = dist_scores.sqrt().detach()
        m = nn.Softplus()
        gamma = -1. * m(gamma).unsqueeze(0)
        if pdiff is None:
            total_effect = torch.clamp(torch.clamp(
                (dist_scores*gamma).exp(), min=1e-5), max=1e5)
        else:
            diff = pdiff.unsqueeze(1).expand(pdiff.shape[0], dist_scores.shape[1], pdiff.shape[1], pdiff.shape[2])
            diff = diff.sigmoid().exp()
            total_effect = torch.clamp(torch.clamp(
                (dist_scores*gamma*diff).exp(), min=1e-5), max=1e5)
        scores = scores * total_effect

    scores.masked_fill_(mask == 0, -1e32)
    scores = F.softmax(scores, dim=-1)
    if zero_pad:
        pad_zero = torch.zeros(bs, head, 1, seqlen).to(device)
        scores = torch.cat([pad_zero, scores[:, :, 1:, :]], dim=2)
    scores = dropout(scores)
    output = torch.matmul(scores, v)
    return output


class LearnablePositionalEmbedding(nn.Module):
    def __init__(self, d_model, max_len=512):
        super().__init__()
        pe = 0.1 * torch.randn(max_len, d_model)
        pe = pe.unsqueeze(0)
        self.weight = nn.Parameter(pe, requires_grad=True)

    def forward(self, x):
        return self.weight[:, :x.size(Dim.seq), :]


class CosinePositionalEmbedding(nn.Module):
    def __init__(self, d_model, max_len=512):
        super().__init__()
        pe = 0.1 * torch.randn(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() *
                             -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.weight = nn.Parameter(pe, requires_grad=False)

    def forward(self, x):
        return self.weight[:, :x.size(Dim.seq), :]


class ParallelKerpleLog(nn.Module):
    def __init__(self, num_attention_heads):
        super().__init__()
        self.heads = num_attention_heads
        self.num_heads_per_partition = self.heads
        self.eps = 1e-2
        
        def get_parameter(scale, init_method):
            if init_method == 'ones':
                return Parameter(torch.ones(
                    self.num_heads_per_partition,
                    dtype=torch.float32,
                )[:, None, None] * scale)
            elif init_method == 'uniform':
                return Parameter(torch.rand(
                    self.num_heads_per_partition,
                    dtype=torch.float32,
                )[:, None, None] * scale)
        
        self.bias_p = get_parameter(2, 'uniform')
        self.bias_a = get_parameter(1, 'uniform')
        self.cached_matrix = None
        self.cached_seq_len = None
    
    def stats(self):
        def get_stats(name, obj):
            return {
                name + '_mean': obj.mean().detach().cpu(),
                name + '_std': obj.std().detach().cpu(),
                name + '_max': obj.max().detach().cpu(),
                name + '_min': obj.min().detach().cpu()
            }
        dd = {}
        self.bias_a.data = self.bias_a.data.clamp(min=self.eps)
        dd.update(get_stats('bias_a', self.bias_a))
        self.bias_p.data = self.bias_p.data.clamp(min=self.eps)
        dd.update(get_stats('bias_p', self.bias_p))
        return dd
    
    def forward(self, x):
        seq_len_q = x.shape[-2]
        seq_len_k = x.shape[-1]
        if self.cached_seq_len != seq_len_k:
            diff = torch.tril(
                torch.arange(seq_len_k, device=x.device).view(seq_len_k, 1).repeat(1, seq_len_k)
                + torch.arange(0, -seq_len_k, -1, device=x.device)
            )
            diff = diff.to(x.dtype)
            self.cached_seq_len = seq_len_k
            self.cached_matrix = diff
        else:
            diff = self.cached_matrix
        self.bias_p.data = self.bias_p.data.clamp(min=self.eps)
        self.bias_a.data = self.bias_a.data.clamp(min=self.eps)
        bias = -self.bias_p * torch.log(1 + self.bias_a * diff)
        
        if seq_len_q != seq_len_k:
            assert (
                seq_len_q == 1
            ), "assumption sq == sk unless at inference time with cache in layer_past with sq == 1"
            if not isinstance(bias, float):
                bias = bias[:, seq_len_k - 1, :].view(bias.shape[0], 1, bias.shape[2])
        return x + bias


class ParallelKerplePower(torch.nn.Module):
    def __init__(self, num_attention_heads):
        super().__init__()
        self.heads = num_attention_heads
        self.num_heads_per_partition = self.heads
        self.eps = 1e-2
        
        def get_parameter(scale, init_method):
            if init_method == 'ones':
                return Parameter(torch.ones(
                               self.num_heads_per_partition,
                               device=torch.cuda.current_device(),
                               dtype=torch.float32,
                               )[:,None,None]*scale )
            elif init_method == 'uniform':
                return Parameter(torch.rand(
                               self.num_heads_per_partition,
                               device=torch.cuda.current_device(),
                               dtype=torch.float32,
                               )[:,None,None]*scale )
        
        self.bias_a, self.bias_p, self.wei_a, self.wei_p = None, None, None, None
        self.bias_p = get_parameter(2, 'uniform') 
        self.bias_a = get_parameter(1, 'uniform')
        self.wei_p = get_parameter(2, 'uniform') 
        self.wei_a = get_parameter(1, 'uniform')
        self.cached_matrix = None
        self.cached_seq_len = None
    
    def _get_slopes(self, n):
        def get_slopes_power_of_2(n):
            start = 2 ** (-(2 ** -(math.log2(n) - 3)))
            ratio = start
            return [start * ratio ** i for i in range(n)]
        if math.log2(n).is_integer():
            return get_slopes_power_of_2(n)
        else:
            closest_power_of_2 = 2 ** math.floor(math.log2(n))
            return (
                get_slopes_power_of_2(closest_power_of_2)
                + self._get_slopes(2 * closest_power_of_2)[0::2][: n - closest_power_of_2]
            )

    def stats(self):
        def get_stats(name, obj):
            return {name+'_mean': obj.mean().detach().cpu(),
                    name+'_std': obj.std().detach().cpu(),
                    name+'_max': obj.max().detach().cpu(),
                    name+'_min': obj.min().detach().cpu()}
        dd = {}
        if self.bias_a is not None:
            self.bias_a.data = self.bias_a.data.clamp(min=self.eps)
            dd.update(get_stats('bias_a', self.bias_a))
        if self.bias_p is not None:
            self.bias_p.data = self.bias_p.data.clamp(min=self.eps, max=2)
            dd.update(get_stats('bias_p', self.bias_p))
        if self.wei_a is not None:
            self.wei_a.data = self.wei_a.data.clamp(min=self.eps)
            dd.update(get_stats('wei_a', self.wei_a))
        if self.wei_p is not None:
            self.wei_p.data = self.wei_p.data.clamp(min=self.eps, max=2)
            dd.update(get_stats('wei_p', self.wei_p))
        return dd
    
    def forward(self, x):
        seq_len_q = x.shape[-2]
        seq_len_k = x.shape[-1]
        if self.cached_seq_len != seq_len_k:
            diff = torch.tril(
                torch.arange(seq_len_k, device=x.device).view(seq_len_k, 1).repeat(1, seq_len_k)
                + torch.arange(0, -seq_len_k, -1, device=x.device)
            )
            diff = diff.to(x.dtype)
            self.cached_seq_len = seq_len_k
            self.cached_matrix = diff
        else:
            diff = self.cached_matrix
        
        if self.bias_p is None and self.bias_a is None:
            bias = 0.0
        else:
            if self.bias_p is not None:
                self.bias_p.data = self.bias_p.data.clamp(min=self.eps, max=2)
                bias = diff.pow(self.bias_p)
            else:
                bias = diff
            if self.bias_a is not None:
                self.bias_a.data = self.bias_a.data.clamp(min=self.eps)
                bias = -bias*self.bias_a
            else:
                bias = -bias

        if self.wei_p is None and self.wei_a is None:
            wei = 1.0
        else:
            if self.wei_p is not None:
                self.wei_p.data = self.wei_p.data.clamp(min=self.eps, max=2)
                wei = diff.pow(self.wei_p)
            else:
                wei = diff
            if self.wei_a is not None:
                self.wei_a.data = self.wei_a.data.clamp(min=self.eps)
                wei = (-wei*self.wei_a).exp()
            else:
                wei = (-wei).exp()
        
        if seq_len_q != seq_len_k:
            assert (
                seq_len_q == 1
            ), "assumption sq == sk unless at inference time with cache in layer_past with sq == 1"
            if type(bias) != float:
                bias = bias[:, seq_len_k - 1, :].view(bias.shape[0], 1, bias.shape[2])
            if type(wei) != float:
                wei = wei[:, seq_len_k - 1, :].view(wei.shape[0], 1, wei.shape[2])
        return x*wei + bias


class T5RelativePositionBias(nn.Module):
    def __init__(self, scale, causal=True, num_buckets=16, max_distance=50):
        super().__init__()
        self.scale = scale
        self.causal = causal
        self.num_buckets = num_buckets
        self.max_distance = max_distance
        self.relative_attention_bias = nn.Embedding(num_buckets, 1)

    @staticmethod
    def _relative_position_bucket(relative_position, causal=True, num_buckets=16, max_distance=50):
        ret = 0
        n = -relative_position
        if not causal:
            num_buckets //= 2
            ret += (n < 0).long() * num_buckets
            n = torch.abs(n)
        else:
            n = torch.max(n, torch.zeros_like(n))
        max_exact = num_buckets // 2
        is_small = n < max_exact
        val_if_large = max_exact + (
            torch.log(n.float() / max_exact) / math.log(max_distance / max_exact) * (num_buckets - max_exact)
        ).long()
        val_if_large = torch.min(val_if_large, torch.full_like(val_if_large, num_buckets - 1))
        ret += torch.where(is_small, n, val_if_large)
        return ret

    def forward(self, x):
        i, j, device = *x.shape[-2:], x.device
        q_pos = torch.arange(i, dtype=torch.long, device=device)
        k_pos = torch.arange(j, dtype=torch.long, device=device)
        rel_pos = rearrange(k_pos, 'j -> 1 j') - rearrange(q_pos, 'i -> i 1')
        rp_bucket = self._relative_position_bucket(rel_pos, causal=self.causal, num_buckets=self.num_buckets, max_distance=self.max_distance)
        values = self.relative_attention_bias(rp_bucket)
        bias = rearrange(values, 'i j 1 -> i j')
        return bias * self.scale


class FIRE(nn.Module):
    def __init__(self, num_heads=12, mlp_width=32, init_c=0.1, init_L=512):
        super(FIRE, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(1, mlp_width),
            nn.ReLU(),
            nn.Linear(mlp_width, num_heads)
        )
        self.c = nn.Parameter(torch.tensor(init_c))
        self.init_L = nn.Parameter(torch.tensor(init_L), requires_grad=False)
        self.L_multiplier = nn.Parameter(torch.tensor(1.0))
        self.eps = 1e-6
            
    def forward(self, x):
        seq_length = x.size(2)
        positions = torch.arange(seq_length, dtype=torch.float, device=x.device)
        rel_distance = positions[:, None] - positions[None, :]
        threshold = torch.abs(self.L_multiplier * self.init_L)
        pos_normalizer = torch.max(positions, threshold)
        pos_normalizer = pos_normalizer[:, None]
        rel_distance = torch.log(torch.abs(self.c * rel_distance) + 1)
        pos_normalizer = torch.log(torch.abs(self.c * pos_normalizer) + 1) + self.eps
        normalized_distance = rel_distance / pos_normalizer
        fire_bias = self.mlp(normalized_distance.unsqueeze(-1))
        fire_bias = fire_bias.unsqueeze(0).permute(0, 3, 1, 2)
        return fire_bias


def compute_sandwich_transform(heads, seq_len, bar_d, device):
    base = 1e4
    positions = torch.arange(seq_len, device=device)[..., None]
    i = torch.arange(bar_d // 2, device=device)
    pos_embs = torch.cat([
        torch.sin(positions / base ** (2 * i / bar_d)),
        torch.cos(positions / base ** (2 * i / bar_d))
    ], dim=-1)
    sandwich = torch.matmul(pos_embs, pos_embs.transpose(0, 1))
    compression_ratio = torch.arange(1, heads + 1, device=device) * 8 / heads
    multi_head_sandwich = sandwich[None, ...] / compression_ratio[..., None, None]
    return multi_head_sandwich
