#!/usr/bin/env python3
"""Analyze scale-wise predictions of trained EpiKT checkpoints.

Upload this file anywhere inside pykt-toolkit-main (the repository root is
recommended), then run it without retraining the model. The script:

1. discovers full EpiKT checkpoints and their config.json files;
2. evaluates every branch independently with the paper's dataset-specific
   pyKT protocol;
3. evaluates the dynamically fused EpiKT prediction;
4. computes pairwise Pearson correlations between protocol-aligned branch
   probabilities;
5. captures dynamic gate weights, sequence positions, and raw predictions;
6. computes fusion gains, prediction disagreement, error overlap, gate entropy,
   gate selection frequencies, and gate behavior by position/outcome;
7. aggregates results over folds and produces NPZ, CSV, JSON, PNG, and PDF files.

Example (run from /autodl-tmp/pykt-toolkit-main):

    python analyze_epikt_branches.py \
        --models-root examples/models \
        --output-dir analysis_outputs/multiscale_episode_evidence \
        --batch-size 256

By default, AL2005, BD2006, and NIPS34 use question-window evaluation with
late-mean fusion, while POJ uses ordinary window evaluation. These correspond
to windowauclate_mean/windowacclate_mean and window_testauc/window_testacc,
respectively.

If the same dataset/fold has multiple checkpoints, the script stops by
default. Pass the exact checkpoint directories with --checkpoints, or use
--duplicate-policy latest only when the newest checkpoint is known to be the
one used in the paper.

Required packages beyond the existing pyKT environment:

    pip install matplotlib
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import os
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch
from sklearn.metrics import accuracy_score, roc_auc_score


DATASET_LABELS = {
    "algebra2005": "AL2005",
    "bridge2algebra2006": "BD2006",
    "nips_task34": "NIPS34",
    "poj": "POJ",
}


@dataclass(frozen=True)
class CheckpointRecord:
    dataset_id: str
    dataset_label: str
    fold: int
    model_name: str
    emb_type: str
    n_scales: int
    run_dir: str
    config_path: str
    checkpoint_path: str


class BranchOutputCapture:
    """Capture branch-specific predictor outputs with forward hooks."""

    def __init__(self, prediction_head: torch.nn.Module) -> None:
        if not hasattr(prediction_head, "predictors"):
            raise RuntimeError(
                "The prediction head has no branch-specific predictors. "
                "Use a full EpiKT checkpoint, not shared_predictor or "
                "feature_mean_original_head."
            )

        predictors = prediction_head.predictors
        self._expected = len(predictors)
        self._outputs: Dict[int, torch.Tensor] = {}
        self._handles = []

        for index, predictor in enumerate(predictors):
            handle = predictor.register_forward_hook(self._make_hook(index))
            self._handles.append(handle)

    def _make_hook(self, index: int):
        def hook(_module, _inputs, output):
            self._outputs[index] = output.detach()

        return hook

    def clear(self) -> None:
        self._outputs.clear()

    def stacked_logits(self) -> torch.Tensor:
        missing = [i for i in range(self._expected) if i not in self._outputs]
        if missing:
            raise RuntimeError(
                "Failed to capture predictor outputs for branches: "
                + ", ".join(map(str, missing))
            )
        return torch.cat([self._outputs[i] for i in range(self._expected)], dim=-1)

    def close(self) -> None:
        for handle in self._handles:
            handle.remove()
        self._handles.clear()


def captured_gate_weights(
    model: torch.nn.Module, expected_branches: int
) -> torch.Tensor:
    prediction_head = model.out
    if not hasattr(prediction_head, "last_branch_gates"):
        raise RuntimeError(
            "The prediction head did not expose last_branch_gates after forward."
        )
    gates = prediction_head.last_branch_gates.detach()
    if gates.ndim != 3 or gates.shape[-1] != expected_branches:
        raise RuntimeError(
            "Unexpected gate tensor shape "
            f"{tuple(gates.shape)}; expected [batch, sequence, "
            f"{expected_branches}]."
        )
    if not torch.allclose(
        gates.sum(dim=-1),
        torch.ones_like(gates[..., 0]),
        atol=1e-5,
        rtol=1e-5,
    ):
        raise RuntimeError("Dynamic gate weights do not sum to one.")
    return gates


def resolve_target_id_tensors(
    qshft: torch.Tensor,
    cshft: torch.Tensor,
    mask: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Return target item/question IDs and explicit KC IDs for valid positions.

    Datasets such as POJ have no separate question tensor in pyKT: qshft has
    shape [batch, 0], while cshft stores the programming-problem IDs. In that
    case cshft is used as the target item and the unavailable KC ID is -1.
    """

    if cshft.shape != mask.shape:
        raise RuntimeError(
            f"cshft shape {tuple(cshft.shape)} does not match mask shape "
            f"{tuple(mask.shape)}."
        )
    if qshft.shape == mask.shape:
        return qshft, cshft
    if qshft.ndim == 2 and qshft.shape[0] == mask.shape[0] and qshft.shape[1] == 0:
        return cshft, torch.full_like(cshft, -1)
    raise RuntimeError(
        f"qshft shape {tuple(qshft.shape)} is neither aligned with the mask "
        "nor an explicitly unavailable [batch, 0] question tensor."
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Collect reusable EpiKT mechanism-analysis predictions, gates, "
            "metrics, diversity statistics, and plots."
        )
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=None,
        help="Path to pykt-toolkit-main. Auto-detected from this script by default.",
    )
    parser.add_argument(
        "--models-root",
        type=Path,
        default=Path("examples/models"),
        help="Parent directory containing the four trained-model directories.",
    )
    parser.add_argument(
        "--model-dir-glob",
        default="*",
        help=(
            "Directory glob applied directly under --models-root. Candidate "
            "configs are subsequently filtered to full multi-scale EpiKT runs."
        ),
    )
    parser.add_argument(
        "--checkpoints",
        type=Path,
        nargs="*",
        default=None,
        help=(
            "Optional exact run directories, config.json files, or *_model.ckpt files. "
            "When supplied, automatic directory scanning is disabled."
        ),
    )
    parser.add_argument(
        "--datasets",
        nargs="+",
        default=["algebra2005", "bridge2algebra2006", "nips_task34", "poj"],
        help="Dataset IDs to analyze. Defaults to the four datasets used by EpiKT.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("analysis_outputs/multiscale_episode_evidence"),
        help="Directory for all analysis outputs.",
    )
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument(
        "--evaluation-protocol",
        choices=["auto", "question_window_late_mean", "window", "standard"],
        default="auto",
        help=(
            "Evaluation protocol. 'auto' uses question-window late_mean for AL2005, "
            "BD2006, and NIPS34, and ordinary window evaluation for POJ."
        ),
    )
    parser.add_argument(
        "--test-split",
        choices=["window", "standard"],
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--device",
        choices=["auto", "cuda", "cpu"],
        default="auto",
        help="Inference device. 'auto' uses CUDA when available.",
    )
    parser.add_argument(
        "--duplicate-policy",
        choices=["error", "latest"],
        default="error",
        help="How to handle multiple checkpoints for the same dataset and fold.",
    )
    parser.add_argument(
        "--expected-folds",
        type=int,
        default=5,
        help="Expected number of folds per dataset; mismatches produce warnings.",
    )
    parser.add_argument(
        "--allow-mixed-scales",
        action="store_true",
        help=(
            "Allow n_scales to differ across folds. Scale-specific summaries will "
            "report the actual number of contributing folds in num_folds."
        ),
    )
    parser.add_argument(
        "--save-predictions",
        action="store_true",
        default=True,
        help=(
            "Save the complete per-fold analysis cache as compressed NPZ "
            "(enabled by default)."
        ),
    )
    parser.add_argument(
        "--no-save-predictions",
        action="store_false",
        dest="save_predictions",
        help="Disable the per-fold NPZ cache. Not recommended for expensive runs.",
    )
    parser.add_argument(
        "--no-reuse-cache",
        action="store_false",
        dest="reuse_cache",
        default=True,
        help=(
            "Ignore existing per-fold mechanism caches and run inference again. "
            "By default, valid caches are reused for interrupted runs."
        ),
    )
    parser.add_argument(
        "--no-plots",
        action="store_true",
        help="Skip PNG/PDF generation; CSV and JSON outputs are still written.",
    )
    return parser.parse_args()


def find_repo_root(explicit: Optional[Path]) -> Path:
    if explicit is not None:
        candidates = [explicit.expanduser().resolve()]
    else:
        here = Path(__file__).resolve()
        candidates = [here.parent] + list(here.parents)

    for candidate in candidates:
        if (
            (candidate / "pykt").is_dir()
            and (candidate / "configs" / "data_config.json").is_file()
        ):
            return candidate

    raise FileNotFoundError(
        "Could not locate pykt-toolkit-main. Upload the script inside the repository "
        "or pass --repo-root /autodl-tmp/pykt-toolkit-main."
    )


def resolve_from_repo(repo_root: Path, path: Path) -> Path:
    path = path.expanduser()
    return path.resolve() if path.is_absolute() else (repo_root / path).resolve()


def config_paths_from_explicit(items: Sequence[Path]) -> List[Path]:
    config_paths: List[Path] = []
    for raw_path in items:
        path = raw_path.expanduser().resolve()
        if path.is_dir():
            config_path = path / "config.json"
        elif path.name == "config.json":
            config_path = path
        elif path.name.endswith("_model.ckpt"):
            config_path = path.parent / "config.json"
        else:
            raise ValueError(f"Unsupported --checkpoints entry: {raw_path}")

        if not config_path.is_file():
            raise FileNotFoundError(f"Missing config.json: {config_path}")
        config_paths.append(config_path)
    return sorted(set(config_paths))


def discover_config_paths(
    models_root: Path, model_dir_glob: str, explicit: Optional[Sequence[Path]]
) -> List[Path]:
    if explicit:
        return config_paths_from_explicit(explicit)

    model_dirs = sorted(path for path in models_root.glob(model_dir_glob) if path.is_dir())
    if not model_dirs:
        raise FileNotFoundError(
            f"No model directories matched {models_root / model_dir_glob}. "
            "Check --models-root and --model-dir-glob."
        )

    config_paths: List[Path] = []
    for model_dir in model_dirs:
        config_paths.extend(model_dir.rglob("config.json"))
    return sorted(set(path.resolve() for path in config_paths))


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def get_epikt_ablation_mode(
    params: Dict[str, Any], model_config: Dict[str, Any]
) -> Optional[str]:
    """Read the EpiKT ablation mode while accepting older checkpoint schemas."""
    for source in (params, model_config):
        if "epikt_ablation" in source:
            return str(source["epikt_ablation"])
        for key, value in source.items():
            if key.endswith("_ablation"):
                return str(value)
    return None


def record_from_config(config_path: Path) -> Optional[CheckpointRecord]:
    config = load_json(config_path)
    params = config.get("params", {})
    model_config = config.get("model_config", {})

    model_name = str(params.get("model_name", "")).strip()
    if not model_name:
        return None

    epikt_ablation = get_epikt_ablation_mode(params, model_config)
    if epikt_ablation != "full":
        return None

    dataset_id = str(params["dataset_name"])
    emb_type = str(params.get("emb_type", "qid"))
    checkpoint_path = config_path.parent / f"{emb_type}_model.ckpt"
    if not checkpoint_path.is_file():
        print(f"[skip] checkpoint not found: {checkpoint_path}", file=sys.stderr)
        return None

    n_scales = int(params.get("n_scales", model_config.get("n_scales", 0)))
    if n_scales < 2:
        print(
            f"[skip] n_scales={n_scales} is not multi-scale: {config_path.parent}",
            file=sys.stderr,
        )
        return None

    return CheckpointRecord(
        dataset_id=dataset_id,
        dataset_label=DATASET_LABELS.get(dataset_id, dataset_id),
        fold=int(params["fold"]),
        model_name=model_name,
        emb_type=emb_type,
        n_scales=n_scales,
        run_dir=str(config_path.parent),
        config_path=str(config_path),
        checkpoint_path=str(checkpoint_path),
    )


def select_records(
    config_paths: Iterable[Path],
    duplicate_policy: str,
    expected_folds: int,
    requested_datasets: Sequence[str],
    allow_mixed_scales: bool,
) -> List[CheckpointRecord]:
    requested = set(requested_datasets)
    discovered: List[CheckpointRecord] = []
    for config_path in config_paths:
        record = record_from_config(config_path)
        if record is not None and record.dataset_id in requested:
            discovered.append(record)

    if not discovered:
        raise RuntimeError(
            "No full EpiKT checkpoints were found for datasets "
            f"{sorted(requested)}. "
            "A valid run directory must contain config.json and <emb_type>_model.ckpt."
        )

    grouped: Dict[Tuple[str, int], List[CheckpointRecord]] = defaultdict(list)
    for record in discovered:
        grouped[(record.dataset_id, record.fold)].append(record)

    selected: List[CheckpointRecord] = []
    duplicate_messages: List[str] = []
    for key, records in sorted(grouped.items()):
        if len(records) == 1:
            selected.append(records[0])
            continue

        if duplicate_policy == "latest":
            chosen = max(records, key=lambda item: Path(item.checkpoint_path).stat().st_mtime)
            print(
                f"[warning] {key} has {len(records)} checkpoints; selecting newest: "
                f"{chosen.run_dir}",
                file=sys.stderr,
            )
            selected.append(chosen)
        else:
            paths = "\n    ".join(record.run_dir for record in records)
            duplicate_messages.append(f"{key}:\n    {paths}")

    if duplicate_messages:
        raise RuntimeError(
            "Multiple checkpoints were found for the same dataset/fold. "
            "Pass exact run directories with --checkpoints or explicitly use "
            "--duplicate-policy latest:\n\n" + "\n\n".join(duplicate_messages)
        )

    folds_by_dataset: Dict[str, List[int]] = defaultdict(list)
    scales_by_dataset: Dict[str, set] = defaultdict(set)
    for record in selected:
        folds_by_dataset[record.dataset_id].append(record.fold)
        scales_by_dataset[record.dataset_id].add(record.n_scales)

    for dataset_id, folds in sorted(folds_by_dataset.items()):
        unique_folds = sorted(set(folds))
        if len(unique_folds) != expected_folds:
            print(
                f"[warning] {dataset_id}: found folds {unique_folds}; "
                f"expected {expected_folds} folds.",
                file=sys.stderr,
            )
        if len(scales_by_dataset[dataset_id]) != 1:
            message = (
                f"{dataset_id} uses inconsistent n_scales across folds: "
                f"{sorted(scales_by_dataset[dataset_id])}. Scale-specific rows "
                "will therefore contain different num_folds values."
            )
            if allow_mixed_scales:
                print(f"[warning] {message}", file=sys.stderr)
            else:
                raise RuntimeError(
                    message + " Re-run with --allow-mixed-scales to analyze the "
                    "checkpoints as saved."
                )

    missing_datasets = sorted(requested - set(folds_by_dataset))
    if missing_datasets:
        print(
            f"[warning] no checkpoints were found for requested datasets: "
            f"{missing_datasets}",
            file=sys.stderr,
        )

    return sorted(selected, key=lambda item: (item.dataset_id, item.fold))


def choose_device(requested: str) -> torch.device:
    if requested == "cpu":
        return torch.device("cpu")
    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("--device cuda was requested, but CUDA is unavailable.")
        return torch.device("cuda")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def sanitize_model_config(config: Dict[str, Any]) -> Dict[str, Any]:
    model_config = copy.deepcopy(config["model_config"])
    for key in ["use_wandb", "learning_rate", "add_uuid", "l2"]:
        model_config.pop(key, None)
    return model_config


def make_data_config(config: Dict[str, Any], repo_root: Path) -> Dict[str, Any]:
    data_config = copy.deepcopy(config["data_config"])
    dataset_id = str(config["params"]["dataset_name"])
    data_config["dataset_name"] = dataset_id

    dpath = Path(data_config["dpath"])
    if not dpath.is_absolute():
        # pyKT config paths such as ../data/algebra2005 are defined relative
        # to the examples directory used by the original training scripts.
        dpath = (repo_root / "examples" / dpath).resolve()
    data_config["dpath"] = str(dpath)
    return data_config


def load_state_dict(checkpoint_path: Path, device: torch.device) -> Dict[str, Any]:
    state = torch.load(str(checkpoint_path), map_location=device)
    if isinstance(state, dict) and "state_dict" in state:
        state = state["state_dict"]
    if not isinstance(state, dict):
        raise TypeError(f"Unexpected checkpoint object in {checkpoint_path}")

    if state and all(key.startswith("module.") for key in state):
        state = {key[len("module.") :]: value for key, value in state.items()}
    return state


def safe_auc(labels: np.ndarray, scores: np.ndarray) -> float:
    if np.unique(labels).size < 2:
        return float("nan")
    return float(roc_auc_score(labels, scores))


def compute_metrics(labels: np.ndarray, scores: np.ndarray) -> Tuple[float, float]:
    auc = safe_auc(labels, scores)
    acc = float(accuracy_score(labels, scores >= 0.5))
    return auc, acc


def evaluate_checkpoint(
    model: torch.nn.Module,
    test_loader,
    device: torch.device,
) -> Dict[str, np.ndarray]:
    model.eval()
    capture = BranchOutputCapture(model.out)

    labels_all: List[np.ndarray] = []
    final_scores_all: List[np.ndarray] = []
    branch_scores_all: List[np.ndarray] = []
    branch_logits_all: List[np.ndarray] = []
    gate_weights_all: List[np.ndarray] = []
    positions_all: List[np.ndarray] = []
    target_questions_all: List[np.ndarray] = []
    target_concepts_all: List[np.ndarray] = []
    sequence_indices_all: List[np.ndarray] = []
    sequence_offset = 0

    try:
        with torch.no_grad():
            for dcur in test_loader:
                q = dcur["qseqs"].to(device)
                c = dcur["cseqs"].to(device)
                r = dcur["rseqs"].to(device)
                qshft = dcur["shft_qseqs"].to(device)
                cshft = dcur["shft_cseqs"].to(device)
                rshft = dcur["shft_rseqs"].to(device)
                sm = dcur["smasks"].to(device).bool()

                cq = torch.cat((q[:, 0:1], qshft), dim=1)
                cc = torch.cat((c[:, 0:1], cshft), dim=1)
                cr = torch.cat((r[:, 0:1], rshft), dim=1)

                capture.clear()
                final_probs, _ = model(cc.long(), cr.long(), cq.long())
                branch_logits = capture.stacked_logits()
                gate_weights = captured_gate_weights(
                    model, branch_logits.shape[-1]
                )

                final_probs = final_probs[:, 1:]
                branch_logits = branch_logits[:, 1:, :]
                branch_probs = torch.sigmoid(branch_logits)
                gate_weights = gate_weights[:, 1:, :]
                positions = torch.arange(
                    1, sm.shape[1] + 1, device=device, dtype=torch.int32
                ).unsqueeze(0).expand(sm.shape[0], -1)
                sequence_indices = torch.arange(
                    sequence_offset,
                    sequence_offset + sm.shape[0],
                    device=device,
                    dtype=torch.int64,
                ).unsqueeze(1).expand(-1, sm.shape[1])
                target_questions, target_concepts = resolve_target_id_tensors(
                    qshft, cshft, sm
                )

                if final_probs.shape != sm.shape:
                    raise RuntimeError(
                        f"Final prediction shape {tuple(final_probs.shape)} does not "
                        f"match smasks shape {tuple(sm.shape)}."
                    )
                if rshft.shape != sm.shape:
                    raise RuntimeError(
                        f"rshft shape {tuple(rshft.shape)} does not match "
                        f"smasks shape {tuple(sm.shape)}."
                    )
                if branch_probs.shape[:2] != sm.shape:
                    raise RuntimeError(
                        f"Branch prediction shape {tuple(branch_probs.shape)} does not "
                        f"match smasks shape {tuple(sm.shape)}."
                    )
                if gate_weights.shape[:2] != sm.shape:
                    raise RuntimeError(
                        f"Gate shape {tuple(gate_weights.shape)} does not match "
                        f"smasks shape {tuple(sm.shape)}."
                    )

                labels_all.append(rshft[sm].detach().cpu().numpy())
                final_scores_all.append(final_probs[sm].detach().cpu().numpy())
                branch_scores_all.append(branch_probs[sm].detach().cpu().numpy())
                branch_logits_all.append(branch_logits[sm].detach().cpu().numpy())
                gate_weights_all.append(gate_weights[sm].detach().cpu().numpy())
                positions_all.append(positions[sm].detach().cpu().numpy())
                target_questions_all.append(
                    target_questions[sm].detach().cpu().numpy()
                )
                target_concepts_all.append(
                    target_concepts[sm].detach().cpu().numpy()
                )
                sequence_indices_all.append(
                    sequence_indices[sm].detach().cpu().numpy()
                )
                sequence_offset += sm.shape[0]
    finally:
        capture.close()

    labels = np.concatenate(labels_all, axis=0).astype(np.int64)
    final_scores = np.concatenate(final_scores_all, axis=0)
    branch_scores = np.concatenate(branch_scores_all, axis=0)
    branch_logits = np.concatenate(branch_logits_all, axis=0)
    gate_weights = np.concatenate(gate_weights_all, axis=0)
    positions = np.concatenate(positions_all, axis=0).astype(np.int32)
    target_questions = np.concatenate(target_questions_all, axis=0).astype(np.int64)
    target_concepts = np.concatenate(target_concepts_all, axis=0).astype(np.int64)
    sequence_indices = np.concatenate(sequence_indices_all, axis=0).astype(np.int64)
    return {
        "labels": labels,
        "final_scores": final_scores,
        "branch_scores": branch_scores,
        "branch_logits": branch_logits,
        "gate_weights": gate_weights,
        "positions": positions,
        "raw_labels": labels,
        "raw_final_scores": final_scores,
        "raw_branch_scores": branch_scores,
        "raw_branch_logits": branch_logits,
        "raw_gate_weights": gate_weights,
        "raw_positions": positions,
        "raw_target_questions": target_questions,
        "raw_target_concepts": target_concepts,
        "raw_sequence_indices": sequence_indices,
    }


def aggregate_by_reference_qidx(
    values: np.ndarray,
    qidxs: np.ndarray,
    reference_qidxs: np.ndarray,
) -> np.ndarray:
    """Average concept-level values for the qidx order emitted by group_fusion."""

    if values.shape[0] != qidxs.shape[0]:
        raise RuntimeError(
            f"Cannot aggregate {values.shape[0]} values with {qidxs.shape[0]} qidxs."
        )
    order = np.argsort(qidxs, kind="stable")
    sorted_qidxs = qidxs[order]
    unique_qidxs, starts, counts = np.unique(
        sorted_qidxs, return_index=True, return_counts=True
    )
    indices = np.searchsorted(unique_qidxs, reference_qidxs)
    if np.any(indices >= unique_qidxs.size) or not np.array_equal(
        unique_qidxs[indices], reference_qidxs
    ):
        raise RuntimeError(
            "The qidxs emitted by group_fusion cannot be aligned with raw "
            "question-window predictions."
        )

    sorted_values = values[order].astype(np.float64, copy=False)
    sums = np.add.reduceat(sorted_values, starts, axis=0)
    if values.ndim == 1:
        means = sums / counts
    else:
        means = sums / counts.reshape((-1,) + (1,) * (values.ndim - 1))
    return means[indices]


def evaluate_question_window_late_mean(
    model: torch.nn.Module,
    test_question_window_loader,
    device: torch.device,
) -> Dict[str, np.ndarray]:
    """Evaluate full and branch predictions with pyKT's exact late_mean logic.

    The model is run once per batch. Its final prediction and all captured branch
    predictions are then passed separately through pyKT's own group_fusion
    implementation. This preserves the qidx/rest handling used by
    evaluate_question without repeating model inference for every branch.
    """

    if test_question_window_loader is None:
        raise RuntimeError(
            "Question-window late_mean evaluation was requested, but "
            "test_question_window_loader is unavailable."
        )

    # Import from the uploaded pyKT repository at runtime. group_fusion is the
    # same helper called by evaluate_question in wandb_predict.py.
    from pykt.models.evaluate_model import group_fusion

    class DiscardWriter:
        def write(self, value: str) -> int:
            return len(value)

    model.eval()
    capture = BranchOutputCapture(model.out)
    total_batches = len(test_question_window_loader)
    progress_every = max(1, total_batches // 10)

    history_keys = ["hs", "sm", "cq", "cc", "cr", "y", "qidxs", "rests", "orirow"]
    histories: Optional[List[Dict[str, Any]]] = None
    label_chunks: Optional[List[List[np.ndarray]]] = None
    score_chunks: Optional[List[List[np.ndarray]]] = None
    qidx_chunks: Optional[List[List[np.ndarray]]] = None
    sink = DiscardWriter()

    raw_qidxs_all: List[np.ndarray] = []
    raw_orirows_all: List[np.ndarray] = []
    raw_rests_all: List[np.ndarray] = []
    raw_labels_all: List[np.ndarray] = []
    raw_final_scores_all: List[np.ndarray] = []
    raw_branch_scores_all: List[np.ndarray] = []
    raw_branch_logits_all: List[np.ndarray] = []
    raw_gate_weights_all: List[np.ndarray] = []
    raw_positions_all: List[np.ndarray] = []
    raw_target_questions_all: List[np.ndarray] = []
    raw_target_concepts_all: List[np.ndarray] = []
    raw_sequence_indices_all: List[np.ndarray] = []
    sequence_offset = 0

    def merge_with_history(
        current: Dict[str, Any], history: Dict[str, Any]
    ) -> Dict[str, Any]:
        if len(history) == 0:
            return {key: current[key] for key in history_keys}

        merged: Dict[str, Any] = {}
        for key in history_keys:
            if key == "hs":
                # A synthetic model name without early fusion is passed below,
                # so hidden states are deliberately absent.
                merged[key] = []
            else:
                merged[key] = torch.cat((history[key], current[key]), dim=0)
        return merged

    try:
        with torch.no_grad():
            for batch_index, data in enumerate(test_question_window_loader, start=1):
                if not isinstance(data, (tuple, list)) or len(data) != 2:
                    raise RuntimeError(
                        "Expected question-window batches as (sequence_data, "
                        "question_metadata)."
                    )
                dcur, dqtest = data

                q = dcur["qseqs"].to(device)
                c = dcur["cseqs"].to(device)
                r = dcur["rseqs"].to(device)
                qshft = dcur["shft_qseqs"].to(device)
                cshft = dcur["shft_cseqs"].to(device)
                rshft = dcur["shft_rseqs"].to(device)
                sm = dcur["smasks"].to(device).bool()

                cq = torch.cat((q[:, 0:1], qshft), dim=1)
                cc = torch.cat((c[:, 0:1], cshft), dim=1)
                cr = torch.cat((r[:, 0:1], rshft), dim=1)

                capture.clear()
                final_probs, _, _ = model(
                    cc.long(), cr.long(), cq.long(), qtest=True
                )
                branch_logits = capture.stacked_logits()
                gate_weights = captured_gate_weights(
                    model, branch_logits.shape[-1]
                )

                final_probs = final_probs[:, 1:]
                branch_logits = branch_logits[:, 1:, :]
                branch_probs = torch.sigmoid(branch_logits)
                gate_weights = gate_weights[:, 1:, :]
                positions = torch.arange(
                    1, sm.shape[1] + 1, device=device, dtype=torch.int32
                ).unsqueeze(0).expand(sm.shape[0], -1)
                sequence_indices = torch.arange(
                    sequence_offset,
                    sequence_offset + sm.shape[0],
                    device=device,
                    dtype=torch.int64,
                ).unsqueeze(1).expand(-1, sm.shape[1])
                target_questions, target_concepts = resolve_target_id_tensors(
                    qshft, cshft, sm
                )

                if final_probs.shape != sm.shape:
                    raise RuntimeError(
                        f"Final prediction shape {tuple(final_probs.shape)} does not "
                        f"match smasks shape {tuple(sm.shape)}."
                    )
                if rshft.shape != sm.shape:
                    raise RuntimeError(
                        f"rshft shape {tuple(rshft.shape)} does not match "
                        f"smasks shape {tuple(sm.shape)}."
                    )
                if branch_probs.shape[:2] != sm.shape:
                    raise RuntimeError(
                        f"Branch prediction shape {tuple(branch_probs.shape)} does not "
                        f"match smasks shape {tuple(sm.shape)}."
                    )
                if gate_weights.shape[:2] != sm.shape:
                    raise RuntimeError(
                        f"Gate shape {tuple(gate_weights.shape)} does not match "
                        f"smasks shape {tuple(sm.shape)}."
                    )

                sm_cpu = sm.detach().cpu()
                for metadata_key in ["qidxs", "orirow", "rests"]:
                    if dqtest[metadata_key].shape != sm_cpu.shape:
                        raise RuntimeError(
                            f"{metadata_key} shape "
                            f"{tuple(dqtest[metadata_key].shape)} does not match "
                            f"smasks shape {tuple(sm.shape)}."
                        )

                raw_qidxs_all.append(
                    dqtest["qidxs"][sm_cpu].detach().cpu().numpy()
                )
                raw_orirows_all.append(
                    dqtest["orirow"][sm_cpu].detach().cpu().numpy()
                )
                raw_rests_all.append(
                    dqtest["rests"][sm_cpu].detach().cpu().numpy()
                )
                raw_labels_all.append(rshft[sm].detach().cpu().numpy())
                raw_final_scores_all.append(
                    final_probs[sm].detach().cpu().numpy()
                )
                raw_branch_scores_all.append(
                    branch_probs[sm].detach().cpu().numpy()
                )
                raw_branch_logits_all.append(
                    branch_logits[sm].detach().cpu().numpy()
                )
                raw_gate_weights_all.append(
                    gate_weights[sm].detach().cpu().numpy()
                )
                raw_positions_all.append(
                    positions[sm].detach().cpu().numpy()
                )
                raw_target_questions_all.append(
                    target_questions[sm].detach().cpu().numpy()
                )
                raw_target_concepts_all.append(
                    target_concepts[sm].detach().cpu().numpy()
                )
                raw_sequence_indices_all.append(
                    sequence_indices[sm].detach().cpu().numpy()
                )
                sequence_offset += sm.shape[0]

                prediction_tensors = [final_probs] + [
                    branch_probs[:, :, index]
                    for index in range(branch_probs.shape[-1])
                ]
                if histories is None:
                    num_outputs = len(prediction_tensors)
                    histories = [{} for _ in range(num_outputs)]
                    label_chunks = [[] for _ in range(num_outputs)]
                    score_chunks = [[] for _ in range(num_outputs)]
                    qidx_chunks = [[] for _ in range(num_outputs)]

                assert histories is not None
                assert label_chunks is not None
                assert score_chunks is not None
                assert qidx_chunks is not None

                for output_index, predictions in enumerate(prediction_tensors):
                    current = {
                        "hs": [],
                        "sm": sm,
                        "cq": cq,
                        "cc": cc,
                        "cr": cr,
                        "y": predictions,
                        "qidxs": dqtest["qidxs"],
                        "rests": dqtest["rests"],
                        "orirow": dqtest["orirow"],
                    }
                    merged = merge_with_history(
                        current, histories[output_index]
                    )
                    grouped, histories[output_index] = group_fusion(
                        merged,
                        model,
                        "epikt_branch_analysis_no_early_fusion",
                        ["late_fusion"],
                        sink,
                    )
                    if grouped:
                        label_chunks[output_index].append(
                            np.asarray(grouped["late_trues"], dtype=np.int64)
                        )
                        score_chunks[output_index].append(
                            np.asarray(grouped["late_mean"], dtype=float)
                        )
                        qidx_chunks[output_index].append(
                            np.asarray(grouped["qidxs"], dtype=np.int64)
                        )

                if (
                    batch_index == 1
                    or batch_index == total_batches
                    or batch_index % progress_every == 0
                ):
                    print(
                        f"    prediction batches: {batch_index}/{total_batches}"
                    )
    finally:
        capture.close()

    if histories is None or label_chunks is None or score_chunks is None:
        raise RuntimeError("Question-window loader produced no prediction batches.")
    assert qidx_chunks is not None

    labels_by_output = [np.concatenate(chunks) for chunks in label_chunks]
    scores_by_output = [np.concatenate(chunks) for chunks in score_chunks]
    qidxs_by_output = [np.concatenate(chunks) for chunks in qidx_chunks]

    reference_labels = labels_by_output[0]
    reference_qidxs = qidxs_by_output[0]
    for output_index in range(1, len(scores_by_output)):
        if not np.array_equal(labels_by_output[output_index], reference_labels):
            raise RuntimeError(
                f"Branch {output_index - 1} produced question labels that do "
                "not align with the final EpiKT output."
            )
        if not np.array_equal(qidxs_by_output[output_index], reference_qidxs):
            raise RuntimeError(
                f"Branch {output_index - 1} produced qidx ordering that does "
                "not align with the final EpiKT output."
            )

    question_final_scores = scores_by_output[0]
    question_branch_scores = np.column_stack(scores_by_output[1:])
    clipped_scores = np.clip(question_branch_scores, 1e-7, 1.0 - 1e-7)
    question_branch_logits = np.log(clipped_scores / (1.0 - clipped_scores))

    raw_qidxs = np.concatenate(raw_qidxs_all).astype(np.int64)
    raw_orirows = np.concatenate(raw_orirows_all).astype(np.int64)
    raw_rests = np.concatenate(raw_rests_all).astype(np.int64)
    raw_labels = np.concatenate(raw_labels_all).astype(np.int64)
    raw_final_scores = np.concatenate(raw_final_scores_all)
    raw_branch_scores = np.concatenate(raw_branch_scores_all)
    raw_branch_logits = np.concatenate(raw_branch_logits_all)
    raw_gate_weights = np.concatenate(raw_gate_weights_all)
    raw_positions = np.concatenate(raw_positions_all).astype(np.int32)
    raw_target_questions = np.concatenate(raw_target_questions_all).astype(np.int64)
    raw_target_concepts = np.concatenate(raw_target_concepts_all).astype(np.int64)
    raw_sequence_indices = np.concatenate(raw_sequence_indices_all).astype(np.int64)

    question_gate_weights = aggregate_by_reference_qidx(
        raw_gate_weights, raw_qidxs, reference_qidxs
    )
    question_positions = aggregate_by_reference_qidx(
        raw_positions, raw_qidxs, reference_qidxs
    )

    return {
        "labels": reference_labels,
        "final_scores": question_final_scores,
        "branch_scores": question_branch_scores,
        "branch_logits": question_branch_logits,
        "gate_weights": question_gate_weights,
        "positions": question_positions,
        "question_ids": reference_qidxs,
        "raw_labels": raw_labels,
        "raw_final_scores": raw_final_scores,
        "raw_branch_scores": raw_branch_scores,
        "raw_branch_logits": raw_branch_logits,
        "raw_gate_weights": raw_gate_weights,
        "raw_positions": raw_positions,
        "raw_question_ids": raw_qidxs,
        "raw_orirows": raw_orirows,
        "raw_rests": raw_rests,
        "raw_target_questions": raw_target_questions,
        "raw_target_concepts": raw_target_concepts,
        "raw_sequence_indices": raw_sequence_indices,
    }


def resolve_evaluation_protocol(
    dataset_id: str,
    requested_protocol: str,
    legacy_test_split: Optional[str],
) -> str:
    if legacy_test_split is not None:
        if requested_protocol != "auto":
            raise ValueError(
                "Do not combine deprecated --test-split with "
                "--evaluation-protocol."
            )
        if legacy_test_split == "standard":
            return "standard"
        requested_protocol = "auto"

    if requested_protocol != "auto":
        return requested_protocol

    if dataset_id == "poj":
        return "window"
    if dataset_id in {"algebra2005", "bridge2algebra2006", "nips_task34"}:
        return "question_window_late_mean"
    raise ValueError(
        f"No automatic evaluation protocol is defined for dataset {dataset_id!r}. "
        "Pass --evaluation-protocol explicitly."
    )


def write_csv(path: Path, rows: Sequence[Dict[str, Any]], fieldnames: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_output_guide(output_dir: Path) -> None:
    guide = """EpiKT mechanism-analysis outputs
================================

Read these files first:
1. branch_metrics_summary.csv       Scale-wise AUC/ACC.
2. fusion_gain_summary.csv          EpiKT gain over the strongest branch.
3. branch_diversity_summary.csv     Correlation, disagreement, and error overlap.
4. gate_statistics_summary.csv      Gate weights and branch-selection frequency.
5. gate_behavior_summary.csv        Gate entropy and deviation from uniform routing.

Additional analyses:
- gate_by_position_summary.csv      Gate weights across sequence-position bins.
- gate_by_outcome_summary.csv       Gate weights by correctness and response label.
- branch_correlations_summary.csv   Fisher-averaged prediction correlations.
- *_per_fold.csv                    Auditable fold-level values behind each summary.
- predictions/*_mechanism_cache.npz Complete reusable inference cache. Do not delete
  these files if future analyses or plots may be needed.
- run_manifest.json                 Checkpoints, folds, protocols, and run settings.
- plots/*.png                       Preview figures.
- plots/*.pdf                       Vector figures for the paper.

The n_scales sensitivity curve still requires separately trained/evaluated
checkpoints for each fixed n_scales value. It cannot be inferred from one model.
"""
    (output_dir / "README_results.txt").write_text(guide, encoding="utf-8")


def validate_mechanism_outputs(
    outputs: Dict[str, np.ndarray], record: CheckpointRecord
) -> None:
    required = [
        "labels", "final_scores", "branch_scores", "branch_logits",
        "gate_weights", "positions", "raw_labels", "raw_final_scores",
        "raw_branch_scores", "raw_branch_logits", "raw_gate_weights",
        "raw_positions", "raw_target_questions", "raw_target_concepts",
        "raw_sequence_indices",
    ]
    missing = [key for key in required if key not in outputs]
    if missing:
        raise RuntimeError(f"Mechanism output is missing arrays: {missing}")

    num_examples = outputs["labels"].shape[0]
    raw_examples = outputs["raw_labels"].shape[0]
    for key in ["final_scores", "positions"]:
        if outputs[key].shape[0] != num_examples:
            raise RuntimeError(
                f"{key} has {outputs[key].shape[0]} rows; expected {num_examples}."
            )
    for key in ["branch_scores", "branch_logits", "gate_weights"]:
        if outputs[key].shape != (num_examples, record.n_scales):
            raise RuntimeError(
                f"{key} has shape {outputs[key].shape}; expected "
                f"({num_examples}, {record.n_scales})."
            )
    for key in [
        "raw_final_scores", "raw_positions", "raw_target_questions",
        "raw_target_concepts", "raw_sequence_indices",
    ]:
        if outputs[key].shape[0] != raw_examples:
            raise RuntimeError(
                f"{key} has {outputs[key].shape[0]} rows; expected {raw_examples}."
            )
    for key in ["raw_branch_scores", "raw_branch_logits", "raw_gate_weights"]:
        if outputs[key].shape != (raw_examples, record.n_scales):
            raise RuntimeError(
                f"{key} has shape {outputs[key].shape}; expected "
                f"({raw_examples}, {record.n_scales})."
            )

    for key in [
        "final_scores", "branch_scores", "branch_logits", "gate_weights",
        "raw_final_scores", "raw_branch_scores", "raw_branch_logits",
        "raw_gate_weights",
    ]:
        if not np.all(np.isfinite(outputs[key])):
            raise RuntimeError(f"{key} contains NaN or infinite values.")
    for key in [
        "final_scores", "branch_scores", "gate_weights", "raw_final_scores",
        "raw_branch_scores", "raw_gate_weights",
    ]:
        if np.any(outputs[key] < -1e-7) or np.any(outputs[key] > 1.0 + 1e-7):
            raise RuntimeError(f"{key} contains values outside [0, 1].")
    for key in ["gate_weights", "raw_gate_weights"]:
        if not np.allclose(outputs[key].sum(axis=1), 1.0, atol=1e-4, rtol=1e-4):
            raise RuntimeError(f"{key} rows do not sum to one.")
    if np.any(outputs["positions"] < 1) or np.any(outputs["raw_positions"] < 1):
        raise RuntimeError("Saved sequence positions must be positive.")


def mechanism_cache_path(output_dir: Path, record: CheckpointRecord) -> Path:
    return (
        output_dir
        / "predictions"
        / f"{record.dataset_id}_fold{record.fold}_mechanism_cache.npz"
    )


def load_mechanism_cache(
    cache_path: Path,
    record: CheckpointRecord,
    evaluation_protocol: str,
) -> Dict[str, np.ndarray]:
    with np.load(cache_path, allow_pickle=False) as archive:
        metadata = {
            "dataset_id": str(archive["dataset_id"].item()),
            "fold": int(archive["fold"].item()),
            "n_scales": int(archive["n_scales"].item()),
            "evaluation_protocol": str(archive["evaluation_protocol"].item()),
            "checkpoint_dir": str(archive["checkpoint_dir"].item()),
        }
        expected = {
            "dataset_id": record.dataset_id,
            "fold": record.fold,
            "n_scales": record.n_scales,
            "evaluation_protocol": evaluation_protocol,
            "checkpoint_dir": record.run_dir,
        }
        mismatches = [
            f"{key}: cached={metadata[key]!r}, expected={expected[key]!r}"
            for key in expected
            if metadata[key] != expected[key]
        ]
        if mismatches:
            raise RuntimeError(
                f"Cache metadata mismatch in {cache_path}: " + "; ".join(mismatches)
            )

        metadata_keys = {
            "dataset_id", "dataset", "fold", "n_scales",
            "evaluation_protocol", "checkpoint_dir",
        }
        outputs = {
            key: archive[key]
            for key in archive.files
            if key not in metadata_keys
        }

    validate_mechanism_outputs(outputs, record)
    return outputs


def save_mechanism_cache(
    output_dir: Path,
    record: CheckpointRecord,
    evaluation_protocol: str,
    outputs: Dict[str, np.ndarray],
) -> Path:
    prediction_dir = output_dir / "predictions"
    prediction_dir.mkdir(parents=True, exist_ok=True)
    cache_payload: Dict[str, Any] = {
        "labels": outputs["labels"],
        "final_scores": outputs["final_scores"],
        "branch_scores": outputs["branch_scores"],
        "branch_logits": outputs["branch_logits"],
        "gate_weights": outputs["gate_weights"],
        "positions": outputs["positions"],
        "raw_labels": outputs["raw_labels"],
        "raw_final_scores": outputs["raw_final_scores"],
        "raw_branch_scores": outputs["raw_branch_scores"],
        "raw_branch_logits": outputs["raw_branch_logits"],
        "raw_gate_weights": outputs["raw_gate_weights"],
        "raw_positions": outputs["raw_positions"],
        "raw_target_questions": outputs["raw_target_questions"],
        "raw_target_concepts": outputs["raw_target_concepts"],
        "raw_sequence_indices": outputs["raw_sequence_indices"],
        "dataset_id": np.asarray(record.dataset_id),
        "dataset": np.asarray(record.dataset_label),
        "fold": np.asarray(record.fold, dtype=np.int32),
        "n_scales": np.asarray(record.n_scales, dtype=np.int32),
        "evaluation_protocol": np.asarray(evaluation_protocol),
        "checkpoint_dir": np.asarray(record.run_dir),
    }
    for optional_key in [
        "question_ids",
        "raw_question_ids",
        "raw_orirows",
        "raw_rests",
    ]:
        if optional_key in outputs:
            cache_payload[optional_key] = outputs[optional_key]

    cache_path = mechanism_cache_path(output_dir, record)
    np.savez_compressed(cache_path, **cache_payload)
    return cache_path


def summarize_metrics(per_fold_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, str, int, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for row in per_fold_rows:
        key = (
            row["dataset_id"],
            row["dataset"],
            int(row["branch_index"]),
            row["branch"],
            row["evaluation_protocol"],
        )
        grouped[key].append(row)

    summary: List[Dict[str, Any]] = []
    for key, rows in sorted(grouped.items(), key=lambda item: (item[0][0], item[0][2])):
        aucs = np.asarray([float(row["auc"]) for row in rows], dtype=float)
        accs = np.asarray([float(row["acc"]) for row in rows], dtype=float)
        ddof = 1 if len(rows) > 1 else 0
        summary.append(
            {
                "dataset_id": key[0],
                "dataset": key[1],
                "branch_index": key[2],
                "branch": key[3],
                "evaluation_protocol": key[4],
                "num_folds": len(rows),
                "auc_mean": float(np.nanmean(aucs)),
                "auc_std": float(np.nanstd(aucs, ddof=ddof)),
                "acc_mean": float(np.nanmean(accs)),
                "acc_std": float(np.nanstd(accs, ddof=ddof)),
            }
        )
    return summary


def correlation_rows(
    record: CheckpointRecord,
    correlation: np.ndarray,
    evaluation_protocol: str,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for i in range(correlation.shape[0]):
        for j in range(correlation.shape[1]):
            rows.append(
                {
                    "dataset_id": record.dataset_id,
                    "dataset": record.dataset_label,
                    "fold": record.fold,
                    "branch_i": i,
                    "branch_j": j,
                    "evaluation_protocol": evaluation_protocol,
                    "pearson_r": float(correlation[i, j]),
                    "checkpoint_dir": record.run_dir,
                }
            )
    return rows


def fusion_gain_row(
    record: CheckpointRecord,
    evaluation_protocol: str,
    labels: np.ndarray,
    final_scores: np.ndarray,
    branch_scores: np.ndarray,
) -> Dict[str, Any]:
    branch_aucs = np.asarray(
        [safe_auc(labels, branch_scores[:, i]) for i in range(branch_scores.shape[1])]
    )
    branch_accs = np.asarray(
        [
            accuracy_score(labels, branch_scores[:, i] >= 0.5)
            for i in range(branch_scores.shape[1])
        ],
        dtype=float,
    )
    final_auc, final_acc = compute_metrics(labels, final_scores)
    best_auc_index = int(np.nanargmax(branch_aucs))
    best_acc_index = int(np.nanargmax(branch_accs))
    branch_predictions = branch_scores >= 0.5
    branch_correct = branch_predictions == labels[:, None]

    return {
        "dataset_id": record.dataset_id,
        "dataset": record.dataset_label,
        "fold": record.fold,
        "n_scales": record.n_scales,
        "evaluation_protocol": evaluation_protocol,
        "epikt_auc": final_auc,
        "best_branch_auc": float(branch_aucs[best_auc_index]),
        "best_auc_branch": best_auc_index,
        "auc_gain": float(final_auc - branch_aucs[best_auc_index]),
        "auc_gain_percent": float(
            100.0 * (final_auc - branch_aucs[best_auc_index])
            / branch_aucs[best_auc_index]
        ),
        "epikt_acc": final_acc,
        "best_branch_acc": float(branch_accs[best_acc_index]),
        "best_acc_branch": best_acc_index,
        "acc_gain": float(final_acc - branch_accs[best_acc_index]),
        "acc_gain_percent": float(
            100.0 * (final_acc - branch_accs[best_acc_index])
            / branch_accs[best_acc_index]
        ),
        "epikt_beats_all_auc": int(final_auc > branch_aucs[best_auc_index]),
        "epikt_beats_all_acc": int(final_acc > branch_accs[best_acc_index]),
        "branch_oracle_acc": float(np.mean(np.any(branch_correct, axis=1))),
        "branch_unanimous_rate": float(
            np.mean(np.all(branch_predictions == branch_predictions[:, :1], axis=1))
        ),
        "num_examples": int(labels.size),
        "checkpoint_dir": record.run_dir,
    }


def branch_diversity_rows(
    record: CheckpointRecord,
    evaluation_protocol: str,
    labels: np.ndarray,
    branch_scores: np.ndarray,
) -> List[Dict[str, Any]]:
    predictions = branch_scores >= 0.5
    correct = predictions == labels[:, None]
    rows: List[Dict[str, Any]] = []
    for i in range(branch_scores.shape[1]):
        for j in range(i + 1, branch_scores.shape[1]):
            wrong_i = ~correct[:, i]
            wrong_j = ~correct[:, j]
            both_wrong = wrong_i & wrong_j
            either_wrong = wrong_i | wrong_j
            error_union = int(either_wrong.sum())
            rows.append(
                {
                    "dataset_id": record.dataset_id,
                    "dataset": record.dataset_label,
                    "fold": record.fold,
                    "n_scales": record.n_scales,
                    "evaluation_protocol": evaluation_protocol,
                    "branch_i": i,
                    "branch_j": j,
                    "pearson_r": float(
                        np.corrcoef(
                            branch_scores[:, i], branch_scores[:, j]
                        )[0, 1]
                    ),
                    "disagreement_rate": float(
                        np.mean(predictions[:, i] != predictions[:, j])
                    ),
                    "both_correct_rate": float(
                        np.mean(correct[:, i] & correct[:, j])
                    ),
                    "double_fault_rate": float(np.mean(both_wrong)),
                    "error_jaccard": (
                        float(both_wrong.sum() / error_union)
                        if error_union > 0
                        else 0.0
                    ),
                    "pair_oracle_acc": float(1.0 - np.mean(both_wrong)),
                    "num_examples": int(labels.size),
                    "checkpoint_dir": record.run_dir,
                }
            )
    return rows


def gate_analysis_rows(
    record: CheckpointRecord,
    evaluation_protocol: str,
    labels: np.ndarray,
    final_scores: np.ndarray,
    gate_weights: np.ndarray,
    raw_gate_weights: np.ndarray,
    raw_positions: np.ndarray,
) -> Tuple[
    List[Dict[str, Any]],
    Dict[str, Any],
    List[Dict[str, Any]],
    List[Dict[str, Any]],
]:
    if gate_weights.shape[1] != record.n_scales:
        raise RuntimeError(
            f"Expected {record.n_scales} gate branches, got {gate_weights.shape[1]}."
        )
    selected_branches = np.argmax(gate_weights, axis=1)
    gate_rows: List[Dict[str, Any]] = []
    for branch_index in range(record.n_scales):
        values = gate_weights[:, branch_index]
        gate_rows.append(
            {
                "dataset_id": record.dataset_id,
                "dataset": record.dataset_label,
                "fold": record.fold,
                "n_scales": record.n_scales,
                "evaluation_protocol": evaluation_protocol,
                "branch_index": branch_index,
                "branch": f"Scale-{branch_index}",
                "gate_mean": float(np.mean(values)),
                "gate_std": float(np.std(values)),
                "gate_p10": float(np.quantile(values, 0.10)),
                "gate_p25": float(np.quantile(values, 0.25)),
                "gate_median": float(np.median(values)),
                "gate_p75": float(np.quantile(values, 0.75)),
                "gate_p90": float(np.quantile(values, 0.90)),
                "argmax_frequency": float(np.mean(selected_branches == branch_index)),
                "num_examples": int(labels.size),
                "checkpoint_dir": record.run_dir,
            }
        )

    clipped = np.clip(gate_weights, 1e-12, 1.0)
    entropy = -np.sum(clipped * np.log(clipped), axis=1)
    if record.n_scales > 1:
        normalized_entropy = entropy / math.log(record.n_scales)
    else:
        normalized_entropy = np.zeros_like(entropy)
    max_weights = np.max(gate_weights, axis=1)
    gate_behavior = {
        "dataset_id": record.dataset_id,
        "dataset": record.dataset_label,
        "fold": record.fold,
        "n_scales": record.n_scales,
        "evaluation_protocol": evaluation_protocol,
        "normalized_entropy_mean": float(np.mean(normalized_entropy)),
        "normalized_entropy_std": float(np.std(normalized_entropy)),
        "max_gate_mean": float(np.mean(max_weights)),
        "max_gate_std": float(np.std(max_weights)),
        "effective_scales_mean": float(np.mean(np.exp(entropy))),
        "distance_from_uniform_mean": float(
            np.mean(np.sum((gate_weights - 1.0 / record.n_scales) ** 2, axis=1))
        ),
        "num_examples": int(labels.size),
        "checkpoint_dir": record.run_dir,
    }

    position_bins = [
        (1, 20, "1-20"),
        (21, 50, "21-50"),
        (51, 100, "51-100"),
        (101, 150, "101-150"),
        (151, np.inf, "151+"),
    ]
    position_rows: List[Dict[str, Any]] = []
    for lower, upper, label in position_bins:
        selected = (raw_positions >= lower) & (raw_positions <= upper)
        if not np.any(selected):
            continue
        for branch_index in range(record.n_scales):
            values = raw_gate_weights[selected, branch_index]
            position_rows.append(
                {
                    "dataset_id": record.dataset_id,
                    "dataset": record.dataset_label,
                    "fold": record.fold,
                    "n_scales": record.n_scales,
                    "evaluation_protocol": evaluation_protocol,
                    "position_bin": label,
                    "position_lower": lower,
                    "position_upper": upper,
                    "branch_index": branch_index,
                    "branch": f"Scale-{branch_index}",
                    "gate_mean": float(np.mean(values)),
                    "gate_std": float(np.std(values)),
                    "num_examples": int(values.size),
                    "checkpoint_dir": record.run_dir,
                }
            )

    final_correct = (final_scores >= 0.5) == labels
    outcome_rows: List[Dict[str, Any]] = []
    for outcome_name, selected in [
        ("correct", final_correct),
        ("incorrect", ~final_correct),
        ("response_0", labels == 0),
        ("response_1", labels == 1),
    ]:
        if not np.any(selected):
            continue
        for branch_index in range(record.n_scales):
            values = gate_weights[selected, branch_index]
            outcome_rows.append(
                {
                    "dataset_id": record.dataset_id,
                    "dataset": record.dataset_label,
                    "fold": record.fold,
                    "n_scales": record.n_scales,
                    "evaluation_protocol": evaluation_protocol,
                    "outcome": outcome_name,
                    "branch_index": branch_index,
                    "branch": f"Scale-{branch_index}",
                    "gate_mean": float(np.mean(values)),
                    "gate_std": float(np.std(values)),
                    "num_examples": int(values.size),
                    "checkpoint_dir": record.run_dir,
                }
            )
    return gate_rows, gate_behavior, position_rows, outcome_rows


def summarize_numeric_rows(
    rows: Sequence[Dict[str, Any]],
    group_fields: Sequence[str],
    value_fields: Sequence[str],
) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[Any, ...], List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row[field] for field in group_fields)].append(row)

    summary: List[Dict[str, Any]] = []
    for key, current_rows in sorted(grouped.items(), key=lambda item: item[0]):
        result = {field: value for field, value in zip(group_fields, key)}
        result["num_folds"] = len(current_rows)
        for field in value_fields:
            values = np.asarray([float(row[field]) for row in current_rows])
            ddof = 1 if values.size > 1 else 0
            result[f"{field}_mean"] = float(np.nanmean(values))
            result[f"{field}_std"] = float(np.nanstd(values, ddof=ddof))
        summary.append(result)
    return summary


def fisher_mean(values: np.ndarray) -> float:
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return float("nan")
    clipped = np.clip(finite, -0.999999, 0.999999)
    return float(np.tanh(np.mean(np.arctanh(clipped))))


def summarize_correlations(
    per_fold_rows: Sequence[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, str, int, int, str], List[float]] = defaultdict(list)
    for row in per_fold_rows:
        key = (
            row["dataset_id"],
            row["dataset"],
            int(row["branch_i"]),
            int(row["branch_j"]),
            row["evaluation_protocol"],
        )
        grouped[key].append(float(row["pearson_r"]))

    summary: List[Dict[str, Any]] = []
    for key, values in sorted(grouped.items()):
        array = np.asarray(values, dtype=float)
        ddof = 1 if array.size > 1 else 0
        summary.append(
            {
                "dataset_id": key[0],
                "dataset": key[1],
                "branch_i": key[2],
                "branch_j": key[3],
                "evaluation_protocol": key[4],
                "num_folds": int(array.size),
                "pearson_fisher_mean": fisher_mean(array),
                "pearson_arithmetic_mean": float(np.nanmean(array)),
                "pearson_std": float(np.nanstd(array, ddof=ddof)),
            }
        )
    return summary


def matrix_from_correlation_summary(
    rows: Sequence[Dict[str, Any]], dataset_id: str
) -> np.ndarray:
    selected = [row for row in rows if row["dataset_id"] == dataset_id]
    n_scales = 1 + max(max(int(row["branch_i"]), int(row["branch_j"])) for row in selected)
    matrix = np.full((n_scales, n_scales), np.nan, dtype=float)
    for row in selected:
        matrix[int(row["branch_i"]), int(row["branch_j"])] = float(
            row["pearson_fisher_mean"]
        )
    np.fill_diagonal(matrix, 1.0)
    return matrix


def save_correlation_matrices(
    output_dir: Path, correlation_summary: Sequence[Dict[str, Any]]
) -> None:
    dataset_ids = sorted({row["dataset_id"] for row in correlation_summary})
    for dataset_id in dataset_ids:
        matrix = matrix_from_correlation_summary(correlation_summary, dataset_id)
        path = output_dir / "correlations" / f"{dataset_id}_fisher_mean.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        labels = [f"Scale-{index}" for index in range(matrix.shape[0])]
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow([""] + labels)
            for label, row in zip(labels, matrix):
                writer.writerow([label] + [f"{value:.8f}" for value in row])


def ensure_matplotlib():
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError(
            "Plot generation requires matplotlib. Install it with: pip install matplotlib"
        ) from exc
    return plt


def plot_metric_summary(
    output_dir: Path,
    metric_summary: Sequence[Dict[str, Any]],
) -> None:
    plt = ensure_matplotlib()
    dataset_ids = sorted({row["dataset_id"] for row in metric_summary})

    for dataset_id in dataset_ids:
        rows = [row for row in metric_summary if row["dataset_id"] == dataset_id]
        rows.sort(key=lambda row: int(row["branch_index"]))
        dataset_label = rows[0]["dataset"]
        labels = [
            "EpiKT" if int(row["branch_index"]) < 0 else f"Scale-{row['branch_index']}"
            for row in rows
        ]

        fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
        colors = ["#2C6F7E" if label != "EpiKT" else "#E04E26" for label in labels]
        x = np.arange(len(rows))

        for ax, metric in zip(axes, ["auc", "acc"]):
            means = np.asarray([float(row[f"{metric}_mean"]) for row in rows])
            stds = np.asarray([float(row[f"{metric}_std"]) for row in rows])
            ax.bar(
                x,
                means,
                yerr=stds,
                color=colors,
                edgecolor="white",
                capsize=3,
                error_kw={"elinewidth": 1.1, "capthick": 1.1},
            )
            ax.set_title(metric.upper())
            ax.set_xticks(x)
            ax.set_xticklabels(labels, rotation=20, ha="right")
            ax.grid(axis="y", alpha=0.3)
            ax.set_axisbelow(True)

        fig.suptitle(f"Scale-wise prediction performance on {dataset_label}")
        fig.tight_layout()
        plot_dir = output_dir / "plots"
        plot_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(plot_dir / f"{dataset_id}_branch_metrics.png", dpi=300)
        fig.savefig(plot_dir / f"{dataset_id}_branch_metrics.pdf")
        plt.close(fig)


def plot_correlation_summary(
    output_dir: Path,
    correlation_summary: Sequence[Dict[str, Any]],
) -> None:
    plt = ensure_matplotlib()
    dataset_ids = sorted({row["dataset_id"] for row in correlation_summary})

    for dataset_id in dataset_ids:
        dataset_rows = [row for row in correlation_summary if row["dataset_id"] == dataset_id]
        dataset_label = dataset_rows[0]["dataset"]
        matrix = matrix_from_correlation_summary(correlation_summary, dataset_id)
        labels = [f"Scale-{index}" for index in range(matrix.shape[0])]

        fig, ax = plt.subplots(figsize=(3.8, 3.3))
        image = ax.imshow(matrix, vmin=-1.0, vmax=1.0, cmap="coolwarm")
        ax.set_xticks(np.arange(matrix.shape[0]))
        ax.set_yticks(np.arange(matrix.shape[0]))
        ax.set_xticklabels(labels)
        ax.set_yticklabels(labels)
        ax.set_title(f"Branch-prediction correlation on {dataset_label}")

        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                value = matrix[i, j]
                text_color = "white" if np.isfinite(value) and abs(value) > 0.55 else "black"
                ax.text(j, i, f"{value:.2f}", ha="center", va="center", color=text_color)

        fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
        fig.tight_layout()
        plot_dir = output_dir / "plots"
        plot_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(plot_dir / f"{dataset_id}_branch_correlation.png", dpi=300)
        fig.savefig(plot_dir / f"{dataset_id}_branch_correlation.pdf")
        plt.close(fig)


def main() -> None:
    args = parse_args()
    repo_root = find_repo_root(args.repo_root)
    sys.path.insert(0, str(repo_root))
    os.chdir(repo_root)

    # Import pyKT only after the repository root is known and on sys.path.
    from pykt.datasets import init_test_datasets
    from pykt.models import init_model

    models_root = resolve_from_repo(repo_root, args.models_root)
    output_dir = resolve_from_repo(repo_root, args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_output_guide(output_dir)
    device = choose_device(args.device)

    config_paths = discover_config_paths(
        models_root=models_root,
        model_dir_glob=args.model_dir_glob,
        explicit=args.checkpoints,
    )
    records = select_records(
        config_paths=config_paths,
        duplicate_policy=args.duplicate_policy,
        expected_folds=args.expected_folds,
        requested_datasets=args.datasets,
        allow_mixed_scales=args.allow_mixed_scales,
    )
    if args.test_split is not None:
        print(
            "Warning: --test-split is deprecated. '--test-split window' is "
            "mapped to the paper-aligned automatic protocol."
        )
    dataset_protocols = {
        record.dataset_id: resolve_evaluation_protocol(
            record.dataset_id, args.evaluation_protocol, args.test_split
        )
        for record in records
    }

    print(f"Repository: {repo_root}")
    print(f"Device: {device}")
    print(f"Evaluation protocol: {args.evaluation_protocol}")
    for dataset_id, protocol in sorted(dataset_protocols.items()):
        print(f"  {DATASET_LABELS.get(dataset_id, dataset_id)}: {protocol}")
    print(f"Selected checkpoints: {len(records)}")
    for record in records:
        print(
            f"  {record.dataset_label} fold={record.fold} "
            f"n_scales={record.n_scales}: {record.run_dir}"
        )

    with (output_dir / "run_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "repo_root": str(repo_root),
                "device": str(device),
                "batch_size": args.batch_size,
                "evaluation_protocol": args.evaluation_protocol,
                "dataset_protocols": dataset_protocols,
                "allow_mixed_scales": args.allow_mixed_scales,
                "save_mechanism_cache": args.save_predictions,
                "reuse_existing_cache": args.reuse_cache,
                "cache_contents": [
                    "labels",
                    "final_scores",
                    "branch_scores",
                    "branch_logits",
                    "gate_weights",
                    "positions",
                    "target_question_and_concept_ids",
                    "source_sequence_indices",
                    "raw_concept_or_window_level_arrays",
                ],
                "records": [asdict(record) for record in records],
            },
            handle,
            indent=2,
            ensure_ascii=False,
        )

    metric_rows: List[Dict[str, Any]] = []
    corr_rows: List[Dict[str, Any]] = []
    fusion_rows: List[Dict[str, Any]] = []
    diversity_rows: List[Dict[str, Any]] = []
    gate_rows: List[Dict[str, Any]] = []
    gate_behavior_rows: List[Dict[str, Any]] = []
    gate_position_rows: List[Dict[str, Any]] = []
    gate_outcome_rows: List[Dict[str, Any]] = []
    loader_cache: Dict[Tuple[str, str], Dict[str, Any]] = {}

    for index, record in enumerate(records, start=1):
        print(
            f"\n[{index}/{len(records)}] Evaluating {record.dataset_label} "
            f"fold {record.fold}"
        )
        evaluation_protocol = dataset_protocols[record.dataset_id]
        cache_path = mechanism_cache_path(output_dir, record)
        loaded_from_cache = args.reuse_cache and cache_path.is_file()

        if loaded_from_cache:
            print(f"  Reusing validated mechanism cache: {cache_path.name}")
            outputs = load_mechanism_cache(
                cache_path, record, evaluation_protocol
            )
        else:
            config = load_json(Path(record.config_path))
            model_config = sanitize_model_config(config)
            data_config = make_data_config(config, repo_root)

            loader_key = (record.dataset_id, record.model_name)
            if loader_key not in loader_cache:
                (
                    test_loader,
                    test_window_loader,
                    _test_question_loader,
                    test_question_window_loader,
                ) = init_test_datasets(
                    data_config, record.model_name, args.batch_size
                )
                loader_cache[loader_key] = {
                    "standard": test_loader,
                    "window": test_window_loader,
                    "question_window_late_mean": test_question_window_loader,
                }

            selected_loader = loader_cache[loader_key][evaluation_protocol]
            if selected_loader is None:
                raise RuntimeError(
                    f"Dataset {record.dataset_label} does not provide a loader for "
                    f"protocol {evaluation_protocol!r}."
                )

            model = init_model(
                record.model_name,
                model_config,
                data_config,
                record.emb_type,
            )
            state = load_state_dict(Path(record.checkpoint_path), device)
            model.load_state_dict(state, strict=True)
            model.to(device)

            if evaluation_protocol == "question_window_late_mean":
                outputs = evaluate_question_window_late_mean(
                    model, selected_loader, device
                )
            else:
                outputs = evaluate_checkpoint(model, selected_loader, device)
        validate_mechanism_outputs(outputs, record)
        labels = outputs["labels"]
        final_scores = outputs["final_scores"]
        branch_scores = outputs["branch_scores"]
        branch_logits = outputs["branch_logits"]
        gate_weights = outputs["gate_weights"]

        if branch_scores.shape[1] != record.n_scales:
            raise RuntimeError(
                f"Config says n_scales={record.n_scales}, but captured "
                f"{branch_scores.shape[1]} branches for {record.run_dir}."
            )

        if args.save_predictions and not loaded_from_cache:
            cache_path = save_mechanism_cache(
                output_dir, record, evaluation_protocol, outputs
            )
            print(f"  Saved reusable mechanism cache: {cache_path.name}")

        for branch_index in range(record.n_scales):
            auc, acc = compute_metrics(labels, branch_scores[:, branch_index])
            metric_rows.append(
                {
                    "dataset_id": record.dataset_id,
                    "dataset": record.dataset_label,
                    "fold": record.fold,
                    "branch_index": branch_index,
                    "branch": f"Scale-{branch_index}",
                    "n_scales": record.n_scales,
                    "evaluation_protocol": evaluation_protocol,
                    "auc": auc,
                    "acc": acc,
                    "num_examples": labels.size,
                    "checkpoint_dir": record.run_dir,
                }
            )

        final_auc, final_acc = compute_metrics(labels, final_scores)
        metric_rows.append(
            {
                "dataset_id": record.dataset_id,
                "dataset": record.dataset_label,
                "fold": record.fold,
                "branch_index": -1,
                "branch": "EpiKT",
                "n_scales": record.n_scales,
                "evaluation_protocol": evaluation_protocol,
                "auc": final_auc,
                "acc": final_acc,
                "num_examples": labels.size,
                "checkpoint_dir": record.run_dir,
            }
        )

        # Use the same protocol-aligned branch probabilities that produce AUC/ACC.
        # For question-window datasets these are late_mean predictions; for POJ
        # they are ordinary window predictions.
        correlation = np.corrcoef(branch_scores, rowvar=False)
        correlation = np.atleast_2d(correlation)
        corr_rows.extend(
            correlation_rows(record, correlation, evaluation_protocol)
        )
        fusion_rows.append(
            fusion_gain_row(
                record,
                evaluation_protocol,
                labels,
                final_scores,
                branch_scores,
            )
        )
        diversity_rows.extend(
            branch_diversity_rows(
                record, evaluation_protocol, labels, branch_scores
            )
        )
        (
            current_gate_rows,
            current_gate_behavior,
            current_position_rows,
            current_outcome_rows,
        ) = gate_analysis_rows(
            record,
            evaluation_protocol,
            labels,
            final_scores,
            gate_weights,
            outputs["raw_gate_weights"],
            outputs["raw_positions"],
        )
        gate_rows.extend(current_gate_rows)
        gate_behavior_rows.append(current_gate_behavior)
        gate_position_rows.extend(current_position_rows)
        gate_outcome_rows.extend(current_outcome_rows)

        print(
            f"  EpiKT AUC={final_auc:.6f}, ACC={final_acc:.6f}, "
            f"examples={labels.size}, protocol={evaluation_protocol}"
        )

        del outputs
        if not loaded_from_cache:
            del model, state
        if device.type == "cuda" and not loaded_from_cache:
            torch.cuda.empty_cache()

    metric_fields = [
        "dataset_id",
        "dataset",
        "fold",
        "branch_index",
        "branch",
        "n_scales",
        "evaluation_protocol",
        "auc",
        "acc",
        "num_examples",
        "checkpoint_dir",
    ]
    write_csv(output_dir / "branch_metrics_per_fold.csv", metric_rows, metric_fields)

    metric_summary = summarize_metrics(metric_rows)
    summary_fields = [
        "dataset_id",
        "dataset",
        "branch_index",
        "branch",
        "evaluation_protocol",
        "num_folds",
        "auc_mean",
        "auc_std",
        "acc_mean",
        "acc_std",
    ]
    write_csv(output_dir / "branch_metrics_summary.csv", metric_summary, summary_fields)

    fusion_fields = [
        "dataset_id", "dataset", "fold", "n_scales", "evaluation_protocol",
        "epikt_auc", "best_branch_auc", "best_auc_branch", "auc_gain",
        "auc_gain_percent", "epikt_acc", "best_branch_acc", "best_acc_branch",
        "acc_gain", "acc_gain_percent", "epikt_beats_all_auc",
        "epikt_beats_all_acc", "branch_oracle_acc", "branch_unanimous_rate",
        "num_examples", "checkpoint_dir",
    ]
    write_csv(output_dir / "fusion_gain_per_fold.csv", fusion_rows, fusion_fields)
    fusion_value_fields = [
        "epikt_auc", "best_branch_auc", "auc_gain", "auc_gain_percent",
        "epikt_acc", "best_branch_acc", "acc_gain", "acc_gain_percent",
        "epikt_beats_all_auc", "epikt_beats_all_acc", "branch_oracle_acc",
        "branch_unanimous_rate",
    ]
    fusion_summary_group = ["dataset_id", "dataset", "evaluation_protocol"]
    fusion_summary = summarize_numeric_rows(
        fusion_rows, fusion_summary_group, fusion_value_fields
    )
    write_csv(
        output_dir / "fusion_gain_summary.csv",
        fusion_summary,
        fusion_summary_group
        + ["num_folds"]
        + [
            suffix
            for field in fusion_value_fields
            for suffix in (f"{field}_mean", f"{field}_std")
        ],
    )

    diversity_fields = [
        "dataset_id", "dataset", "fold", "n_scales", "evaluation_protocol",
        "branch_i", "branch_j", "pearson_r", "disagreement_rate",
        "both_correct_rate", "double_fault_rate", "error_jaccard",
        "pair_oracle_acc", "num_examples", "checkpoint_dir",
    ]
    write_csv(
        output_dir / "branch_diversity_per_fold.csv",
        diversity_rows,
        diversity_fields,
    )
    diversity_value_fields = [
        "pearson_r", "disagreement_rate", "both_correct_rate",
        "double_fault_rate", "error_jaccard", "pair_oracle_acc",
    ]
    diversity_summary_group = [
        "dataset_id", "dataset", "evaluation_protocol", "n_scales",
        "branch_i", "branch_j",
    ]
    diversity_summary = summarize_numeric_rows(
        diversity_rows, diversity_summary_group, diversity_value_fields
    )
    write_csv(
        output_dir / "branch_diversity_summary.csv",
        diversity_summary,
        diversity_summary_group
        + ["num_folds"]
        + [
            suffix
            for field in diversity_value_fields
            for suffix in (f"{field}_mean", f"{field}_std")
        ],
    )

    gate_fields = [
        "dataset_id", "dataset", "fold", "n_scales", "evaluation_protocol",
        "branch_index", "branch", "gate_mean", "gate_std", "gate_p10",
        "gate_p25", "gate_median", "gate_p75", "gate_p90",
        "argmax_frequency", "num_examples", "checkpoint_dir",
    ]
    write_csv(output_dir / "gate_statistics_per_fold.csv", gate_rows, gate_fields)
    gate_value_fields = [
        "gate_mean", "gate_std", "gate_p10", "gate_p25", "gate_median",
        "gate_p75", "gate_p90", "argmax_frequency",
    ]
    gate_summary_group = [
        "dataset_id", "dataset", "evaluation_protocol", "n_scales",
        "branch_index", "branch",
    ]
    gate_summary = summarize_numeric_rows(
        gate_rows, gate_summary_group, gate_value_fields
    )
    write_csv(
        output_dir / "gate_statistics_summary.csv",
        gate_summary,
        gate_summary_group
        + ["num_folds"]
        + [
            suffix
            for field in gate_value_fields
            for suffix in (f"{field}_mean", f"{field}_std")
        ],
    )

    gate_behavior_fields = [
        "dataset_id", "dataset", "fold", "n_scales", "evaluation_protocol",
        "normalized_entropy_mean", "normalized_entropy_std", "max_gate_mean",
        "max_gate_std", "effective_scales_mean", "distance_from_uniform_mean",
        "num_examples", "checkpoint_dir",
    ]
    write_csv(
        output_dir / "gate_behavior_per_fold.csv",
        gate_behavior_rows,
        gate_behavior_fields,
    )
    gate_behavior_value_fields = [
        "normalized_entropy_mean", "max_gate_mean", "effective_scales_mean",
        "distance_from_uniform_mean",
    ]
    gate_behavior_summary_group = [
        "dataset_id", "dataset", "evaluation_protocol", "n_scales",
    ]
    gate_behavior_summary = summarize_numeric_rows(
        gate_behavior_rows,
        gate_behavior_summary_group,
        gate_behavior_value_fields,
    )
    write_csv(
        output_dir / "gate_behavior_summary.csv",
        gate_behavior_summary,
        gate_behavior_summary_group
        + ["num_folds"]
        + [
            suffix
            for field in gate_behavior_value_fields
            for suffix in (f"{field}_mean", f"{field}_std")
        ],
    )

    gate_position_fields = [
        "dataset_id", "dataset", "fold", "n_scales", "evaluation_protocol",
        "position_bin", "position_lower", "position_upper", "branch_index",
        "branch", "gate_mean", "gate_std", "num_examples", "checkpoint_dir",
    ]
    write_csv(
        output_dir / "gate_by_position_per_fold.csv",
        gate_position_rows,
        gate_position_fields,
    )
    gate_position_summary_group = [
        "dataset_id", "dataset", "evaluation_protocol", "n_scales",
        "position_bin", "branch_index", "branch",
    ]
    gate_position_summary = summarize_numeric_rows(
        gate_position_rows,
        gate_position_summary_group,
        ["gate_mean"],
    )
    write_csv(
        output_dir / "gate_by_position_summary.csv",
        gate_position_summary,
        gate_position_summary_group
        + ["num_folds", "gate_mean_mean", "gate_mean_std"],
    )

    gate_outcome_fields = [
        "dataset_id", "dataset", "fold", "n_scales", "evaluation_protocol",
        "outcome", "branch_index", "branch", "gate_mean", "gate_std",
        "num_examples", "checkpoint_dir",
    ]
    write_csv(
        output_dir / "gate_by_outcome_per_fold.csv",
        gate_outcome_rows,
        gate_outcome_fields,
    )
    gate_outcome_summary_group = [
        "dataset_id", "dataset", "evaluation_protocol", "n_scales", "outcome",
        "branch_index", "branch",
    ]
    gate_outcome_summary = summarize_numeric_rows(
        gate_outcome_rows,
        gate_outcome_summary_group,
        ["gate_mean"],
    )
    write_csv(
        output_dir / "gate_by_outcome_summary.csv",
        gate_outcome_summary,
        gate_outcome_summary_group
        + ["num_folds", "gate_mean_mean", "gate_mean_std"],
    )

    corr_fields = [
        "dataset_id",
        "dataset",
        "fold",
        "branch_i",
        "branch_j",
        "evaluation_protocol",
        "pearson_r",
        "checkpoint_dir",
    ]
    write_csv(output_dir / "branch_correlations_per_fold.csv", corr_rows, corr_fields)

    correlation_summary = summarize_correlations(corr_rows)
    corr_summary_fields = [
        "dataset_id",
        "dataset",
        "branch_i",
        "branch_j",
        "evaluation_protocol",
        "num_folds",
        "pearson_fisher_mean",
        "pearson_arithmetic_mean",
        "pearson_std",
    ]
    write_csv(
        output_dir / "branch_correlations_summary.csv",
        correlation_summary,
        corr_summary_fields,
    )
    save_correlation_matrices(output_dir, correlation_summary)

    if not args.no_plots:
        plot_metric_summary(output_dir, metric_summary)
        plot_correlation_summary(output_dir, correlation_summary)

    print(f"\nDone. Results saved to: {output_dir}")
    print("Primary files:")
    print(f"  {output_dir / 'README_results.txt'}")
    print(f"  {output_dir / 'branch_metrics_summary.csv'}")
    print(f"  {output_dir / 'fusion_gain_summary.csv'}")
    print(f"  {output_dir / 'branch_diversity_summary.csv'}")
    print(f"  {output_dir / 'branch_correlations_summary.csv'}")
    print(f"  {output_dir / 'gate_statistics_summary.csv'}")
    print(f"  {output_dir / 'gate_behavior_summary.csv'}")
    if args.save_predictions:
        print(f"  {output_dir / 'predictions'}")
    if not args.no_plots:
        print(f"  {output_dir / 'plots'}")


if __name__ == "__main__":
    main()
